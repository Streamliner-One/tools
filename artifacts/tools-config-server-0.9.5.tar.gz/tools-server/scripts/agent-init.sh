#!/bin/bash
# agent-init.sh — Configure OpenClaw workspace for tools server integration
#
# Run after install or whenever server URL / password changes.
# Safe to run multiple times — detects and updates existing config.
#
# Usage:
#   bash agent-init.sh
#   OPENCLAW_WORKSPACE=/path/to/workspace TOOLS_SERVER_URL=https://x.x.x.x:8443 bash agent-init.sh

set -euo pipefail

# ── Config ──────────────────────────────────────────────────────────────────
WORKSPACE="${OPENCLAW_WORKSPACE:-$HOME/.openclaw/workspace}"
SERVER_URL="${TOOLS_SERVER_URL:-https://100.84.57.51:8443}"
SERVER_PASS="${TOOLS_SERVER_PASSWORD:-mel2026}"
AGENTS_MD="$WORKSPACE/AGENTS.md"
CONNECTORS_MD="$WORKSPACE/CONNECTORS.md"
MARKER_BEGIN="<!-- TOOLS_SERVER_BEGIN -->"
MARKER_END="<!-- TOOLS_SERVER_END -->"
MARKER_DW_BEGIN="<!-- DATA_WRITE_BEGIN -->"
MARKER_DW_END="<!-- DATA_WRITE_END -->"

GREEN='\033[0;32m'; YELLOW='\033[1;33m'; BLUE='\033[0;34m'; NC='\033[0m'
log()     { echo -e "${BLUE}[agent-init]${NC} $1"; }
success() { echo -e "${GREEN}[agent-init]${NC} ✅ $1"; }
warning() { echo -e "${YELLOW}[agent-init]${NC} ⚠️  $1"; }

# ── The exact agent instruction block ────────────────────────────────────────
agent_block() {
cat <<BLOCK
${MARKER_BEGIN}
### Credentials & API Calls

**Flow for every external service call:**
\`\`\`
1. Check TOOLS.md mtime — if changed since last read, re-read it now
2. Match intent → find service in TOOLS.md (use-when, call template, params)
3. GET /api/credentials/{service} → get primaryKey (and /token for OAuth)
4. Execute the call directly using the template from TOOLS.md
\`\`\`

TOOLS.md contains the complete call template per service — correct endpoint,
auth header format, params. It regenerates automatically on every credential
change. **Never guess a URL or auth pattern. Never skip step 1.**

**Tools server access** (\`exec\` + \`curl\` only — \`web_fetch\` blocks private IPs):
\`\`\`bash
COOKIE=\$(mktemp); trap "rm -f \$COOKIE" EXIT
curl -sk -c "\$COOKIE" -X POST ${SERVER_URL}/api/login \\
  -H 'Content-Type: application/json' -d '{"password":"${SERVER_PASS}"}' >/dev/null
curl -sk -b "\$COOKIE" ${SERVER_URL}/api/credentials/<service>
# <service> = package name e.g. notion, readwise, github
# .primaryKey = the main auth value regardless of internal field name
# OAuth: GET ${SERVER_URL}/api/credentials/<service>/token → bearer token
\`\`\`

**Permanent exceptions (2):**
- \`web_fetch\` blocks private IPs → always \`exec\` + \`curl\` for tools server
- \`google-workspace\` → local CLI only: \`GOG_KEYRING_PASSWORD=\$(cat memory/gog_keyring_password.txt) gog <cmd> --account <email>\`

See \`CONNECTORS.md\` only if something is genuinely unclear.
${MARKER_END}
BLOCK
}

# ── Write or update CONNECTORS.md ────────────────────────────────────────────
write_connectors_md() {
  cat > "$CONNECTORS_MD" <<EOF
# CONNECTORS.md

The tools server is the source of truth for credentials, routing, and call templates.
This file documents only the two things the server cannot tell you.

## 1. How to reach the tools server

\`web_fetch\` blocks private IPs — always use \`exec\` + \`curl\`:

\`\`\`bash
COOKIE=\$(mktemp); trap "rm -f \$COOKIE" EXIT
curl -sk -c "\$COOKIE" -X POST ${SERVER_URL}/api/login \\
  -H 'Content-Type: application/json' -d '{"password":"${SERVER_PASS}"}' >/dev/null
curl -sk -b "\$COOKIE" ${SERVER_URL}/api/credentials/<service>
\`\`\`

Always \`https://\` — \`http://\` silently fails.

## 2. Google Workspace (gog CLI)

OAuth token lives in the local keyring, not on the tools server:

\`\`\`bash
GOG_KEYRING_PASSWORD=\$(cat ~/.openclaw/workspace/memory/gog_keyring_password.txt)
GOG_KEYRING_PASSWORD="\$GOG_KEYRING_PASSWORD" gog <command> --account <email>
\`\`\`

Everything else: ask the tools server.
EOF
  success "CONNECTORS.md written"
}

# ── Data-Write Protocol block ────────────────────────────────────────────────
data_write_block() {
cat <<BLOCK
${MARKER_DW_BEGIN}
## Data-Write Protocol

**TOOLS.md may contain an "Intent Rules" section.** These are mandatory — not suggestions. When a user message matches a trigger phrase, write to the target file *before* generating a response, then confirm naturally.

**Rule:** past tense = immediate write. Future/uncertain = ask first.
**Canonical files are ground truth.** Mem0 is context. Never substitute one for the other.

If Intent Rules exist in TOOLS.md: follow them exactly — triggers, entities, target files.
If a user updates data not covered by a rule: update the relevant file anyway, then suggest adding a rule.
${MARKER_DW_END}
BLOCK
}

# ── Patch AGENTS.md ───────────────────────────────────────────────────────────
patch_agents_md() {
  if [ ! -f "$AGENTS_MD" ]; then
    warning "AGENTS.md not found at $AGENTS_MD — creating minimal version"
    cat > "$AGENTS_MD" <<EOF
# AGENTS.md - Your Workspace

## Every Session

1. Read \`SOUL.md\` — who you are
2. Read \`USER.md\` — who you're helping
3. Read \`memory/YYYY-MM-DD.md\` (today + yesterday) for recent context

EOF
  fi

  # Check if block already exists
  if grep -q "$MARKER_BEGIN" "$AGENTS_MD" 2>/dev/null; then
    log "Intent router section found — updating..."
    # Replace existing block
    python3 - "$AGENTS_MD" <<PYEOF
import sys, re
path = sys.argv[1]
content = open(path).read()
new_block = open('/dev/stdin').read() if False else """$(agent_block)"""
pattern = r'<!-- TOOLS_SERVER_BEGIN -->.*?<!-- TOOLS_SERVER_END -->'
updated = re.sub(pattern, new_block.strip(), content, flags=re.DOTALL)
open(path, 'w').write(updated)
PYEOF
    success "Intent router section updated in AGENTS.md"
  else
    log "Inserting intent router section into AGENTS.md..."
    # Find "### Credentials" or append before "## Memory" or at end of first section
    TARGET="### Credentials & API Calls"
    if grep -q "$TARGET" "$AGENTS_MD"; then
      # Replace existing section
      python3 - "$AGENTS_MD" <<PYEOF
import sys, re
path = sys.argv[1]
content = open(path).read()
block = """$(agent_block)"""
# Replace from "### Credentials" to next "##" heading or end
pattern = r'(### Credentials & API Calls.*?)(?=\n## |\Z)'
updated = re.sub(pattern, block.strip(), content, flags=re.DOTALL)
open(path, 'w').write(updated)
PYEOF
    else
      # Append after "## Every Session" block or at logical insert point
      python3 - "$AGENTS_MD" <<PYEOF
import sys, re
path = sys.argv[1]
content = open(path).read()
block = """$(agent_block)"""
# Insert after "## Every Session" section (before next ##)
pattern = r'(## Every Session\n.*?)(\n## )'
match = re.search(pattern, content, re.DOTALL)
if match:
    insert_at = match.start(2)
    updated = content[:insert_at] + '\n' + block.strip() + '\n' + content[insert_at:]
else:
    updated = content.rstrip() + '\n\n' + block.strip() + '\n'
open(path, 'w').write(updated)
PYEOF
    fi
    success "Intent router section inserted into AGENTS.md"
  fi

  # Inject Data-Write Protocol block (idempotent)
  if grep -q "$MARKER_DW_BEGIN" "$AGENTS_MD" 2>/dev/null; then
    log "Data-Write Protocol section found — updating..."
    python3 - "$AGENTS_MD" <<PYEOF
import sys, re
path = sys.argv[1]
content = open(path).read()
new_block = """$(data_write_block)"""
pattern = r'<!-- DATA_WRITE_BEGIN -->.*?<!-- DATA_WRITE_END -->'
updated = re.sub(pattern, new_block.strip(), content, flags=re.DOTALL)
open(path, 'w').write(updated)
PYEOF
    success "Data-Write Protocol section updated in AGENTS.md"
  else
    log "Inserting Data-Write Protocol section into AGENTS.md..."
    python3 - "$AGENTS_MD" <<PYEOF
import sys, re
path = sys.argv[1]
content = open(path).read()
block = """$(data_write_block)"""
# Insert after Memory section or before Tools & Technology
pattern = r'(\n## Tools)'
match = re.search(pattern, content)
if match:
    insert_at = match.start(0)
    updated = content[:insert_at] + '\n\n' + block.strip() + '\n' + content[insert_at:]
else:
    updated = content.rstrip() + '\n\n' + block.strip() + '\n'
open(path, 'w').write(updated)
PYEOF
    success "Data-Write Protocol section inserted into AGENTS.md"
  fi
}

# ── Verify ────────────────────────────────────────────────────────────────────
verify() {
  log "Verifying setup..."

  # Tools server reachable?
  COOKIE=$(mktemp); trap "rm -f $COOKIE" EXIT
  HTTP=$(curl -sk -w "%{http_code}" -o /dev/null -c "$COOKIE" \
    -X POST "$SERVER_URL/api/login" \
    -H 'Content-Type: application/json' \
    -d "{\"password\":\"$SERVER_PASS\"}" --max-time 5)
  if [ "$HTTP" = "200" ]; then
    COUNT=$(curl -sk -b "$COOKIE" "$SERVER_URL/api/credentials" | \
      python3 -c "import sys,json; print(len(json.load(sys.stdin).get('credentials',[])))" 2>/dev/null || echo "?")
    success "Tools server reachable — $COUNT credentials configured"
  else
    warning "Tools server not reachable at $SERVER_URL (HTTP $HTTP)"
  fi

  # TOOLS.md exists?
  if [ -f "$WORKSPACE/TOOLS.md" ]; then
    LINES=$(wc -l < "$WORKSPACE/TOOLS.md")
    success "TOOLS.md exists ($LINES lines)"
  else
    warning "TOOLS.md not found — server will generate it on first credential save"
  fi

  # AGENTS.md patched?
  grep -q "$MARKER_BEGIN" "$AGENTS_MD" && \
    success "AGENTS.md: intent router section present" || \
    warning "AGENTS.md: intent router section missing"
  grep -q "$MARKER_DW_BEGIN" "$AGENTS_MD" && \
    success "AGENTS.md: data-write protocol section present" || \
    warning "AGENTS.md: data-write protocol section missing"

  # CONNECTORS.md exists?
  [ -f "$CONNECTORS_MD" ] && success "CONNECTORS.md exists" || warning "CONNECTORS.md missing"
}

# ── Main ──────────────────────────────────────────────────────────────────────
main() {
  echo ""
  echo "🔧 OpenClaw Agent Init — Tools Server Integration"
  echo "=================================================="
  echo "  Workspace:  $WORKSPACE"
  echo "  Server:     $SERVER_URL"
  echo ""

  mkdir -p "$WORKSPACE"
  write_connectors_md
  patch_agents_md
  verify

  echo ""
  success "Agent configured. On the next session, the agent is ready to use all services."
  echo ""
}

main "$@"
