# tools-config-server

Credential vault and intent router for OpenClaw agents. Stores API keys, generates
per-service call templates, and keeps agents informed via a self-updating `TOOLS.md`.

> For installation, see [install repo](https://github.com/Streamliner-One/tools).  
> For usage examples, see `lib/usage.js` and the generated `TOOLS.md`.

---

## How it works

```
User fills credentials in dashboard
  → server validates + stores
  → TOOLS.md regenerates (method, URL, auth header, params, common errors)
  → agent reads TOOLS.md on session start, checks mtime before each call
  → agent fetches primaryKey from /api/credentials/{service}
  → agent executes call directly — no guessing, no docs to read
```

On fresh install, `scripts/agent-init.sh` runs automatically and patches the agent's
`AGENTS.md` with the 4-step intent router flow. The agent is operational after the
first credential is saved — zero manual config.

---

## Quick Start (local dev)

```bash
cd tools-server
npm install

# Development
npm run dev

# Production (Tailscale)
node server.js --bind 100.x.x.x:8443 --password "your-secure-password"
```

## CLI Flags

| Flag | Description | Default |
|------|-------------|---------|
| `--bind HOST:PORT` | Bind address | `127.0.0.1:8080` |
| `--password PASS` | Access password | Auto-generated |
| `--temp MINUTES` | Auto-shutdown after N min | Disabled |
| `--https` | Enable HTTPS (self-signed) | Disabled |
| `--data-dir PATH` | Data directory | `~/.openclaw/workspace` |

---

## Architecture

```
┌────────────┐    ┌──────────────────┐    ┌──────────────────┐
│  Dashboard │───▶│   Express API    │───▶│  Registry JSON   │
│  (Dark UI) │    │   + Auth         │    │  (Local FS)      │
└────────────┘    └──────────────────┘    └──────────────────┘
                          │
                          ▼
               ┌──────────────────────┐
               │  TOOLS.md Generator  │  ← fires on every credential change
               │  (routing + templates│
               └──────────────────────┘
                          │
                          ▼
               ┌──────────────────────┐
               │  TOOLS.md            │  ← agent reads this
               │  (24 call templates) │
               └──────────────────────┘
```

**Key design decisions:**
- Agent calls external APIs directly — server is credential vault only, no proxy
- `primaryKey` field on every response — normalized auth value regardless of field name
- Package-name lookup — `readwise` resolves to `readwise-1772...` automatically
- `generateToolsMd()` fires on every create/update/delete — TOOLS.md is always current
- mtime-based freshness — agent stats the file, re-reads only when credentials changed

---

## Key Files

| File | Purpose |
|------|---------|
| `schema.js` | Service definitions — fields, validation, labels |
| `server.js` | Express API, auth, health probes, credential endpoints |
| `lib/usage.js` | Complete call templates for all 33 services |
| `lib/generator.js` | Renders TOOLS.md from registry + usage templates |
| `lib/registry.js` | Credential CRUD + package-name resolution |
| `scripts/agent-init.sh` | Post-install: patches AGENTS.md, writes CONNECTORS.md |
| `tools-registry.json` | Runtime credential store (never commit) |
| `TOOLS.md` | Auto-generated agent reference (never commit) |
| `CHANGELOG.md` | Version history |
| `RELEASE_CHECKLIST.md` | Release process for all 3 repos |

---

## API Endpoints

| Method | Path | Description |
|--------|------|-------------|
| `GET` | `/api/credentials` | All credentials with primaryKey + usage |
| `GET` | `/api/credentials/:id` | Single credential + primaryKey |
| `GET` | `/api/credentials/:id/usage` | Usage example (curl, params, errors) |
| `POST` | `/api/credentials/:id/example/render` | Rendered curl + request object |
| `POST` | `/api/credentials/:id/example/run` | Execute request server-side |
| `PUT` | `/api/credentials/:id` | Merge-update fields → regenerates TOOLS.md |
| `PUT` | `/api/credentials/:id/fields` | Update specific fields → regenerates TOOLS.md |
| `PUT` | `/api/credentials/:id/rename` | Rename → regenerates TOOLS.md |
| `DELETE` | `/api/credentials/:id` | Delete → regenerates TOOLS.md |
| `GET` | `/api/credentials/amadeus/token` | Cached OAuth2 bearer token |
| `GET` | `/api/health` | Full health snapshot (all services) |
| `GET` | `/api/health?refresh=true` | Force fresh health check |
| `GET` | `/api/router?intent=hotel_search` | Intent → service routing |
| `GET` | `/api/intent-rules` | List all data-write intent rules |
| `GET` | `/api/intent-rules/:id` | Get single rule |
| `POST` | `/api/intent-rules` | Create or update rule (upsert by id) → regenerates TOOLS.md |
| `DELETE` | `/api/intent-rules/:id` | Delete rule → regenerates TOOLS.md |
| `GET` | `/api/version` | Current version |

---

## Intent Rules (Data-Write Triggers)

Intent rules solve the "judgment problem": agents understand data changes but may not write them to canonical files consistently. Rules make file writes deterministic — trigger detected → write → respond.

Rules are stored in `registry.meta.intentRules` and injected into TOOLS.md automatically. Each rule is marked **mandatory and non-optional** in TOOLS.md so the agent cannot skip execution.

**Rule types:**

| Type | When triggered | Use for |
|------|---------------|---------|
| `write` | Update a canonical file immediately | Flight changes, location moves, contact edits |
| `behavior` | Apply a response constraint | Suppress extra text, enforce formats, silent acks |

**Rule schema (`write`):**
```json
{
  "id": "flight_update",
  "type": "write",
  "intent": "flight_update",
  "description": "Update travel.json when user confirms a flight reschedule",
  "triggers": ["moved to", "changed to", "rescheduled to", "flight is now"],
  "entities": ["flight_number", "new_date", "new_time"],
  "action": "write",
  "target": "travel.json",
  "confirmationTemplate": "Got it — {flight_number} updated to {new_date}.",
  "notes": "Past tense = immediate write. Future/uncertain = ask first."
}
```

**Rule schema (`behavior`):**
```json
{
  "id": "heartbeat_ack",
  "type": "behavior",
  "intent": "heartbeat_ack",
  "description": "Heartbeat polls must be acknowledged silently",
  "triggers": ["Read HEARTBEAT.md if it exists", "If nothing needs attention, reply HEARTBEAT_OK"],
  "action": "respond_only",
  "constraint": "Reply HEARTBEAT_OK only. No extra text unless urgent alert detected.",
  "confirmationTemplate": "HEARTBEAT_OK",
  "notes": "User has scheduled cron check-ins. Heartbeat polls are silent acks."
}
```

Rules are **user-specific** — every installation defines its own files, triggers, and behaviors. The agent can add/update rules via the API; users can view and edit them in the dashboard.

---

## Adding a New Service

1. Add schema to `schema.js`:
```javascript
myService: {
  id: 'myService',
  name: 'My Service',
  category: 'custom',
  icon: '🔧',
  description: 'What it does',
  fields: [
    { key: 'apiKey', label: 'API Key', type: 'password', required: true, sensitive: true }
  ]
}
```

2. Add health probe to `server.js` under `healthCheckers`

3. Add call template to `lib/usage.js` under `getExampleDefinition`:
```javascript
myService: {
  title: 'My Service — do thing',
  summary: 'One line description.',
  allowedHosts: ['api.myservice.com'],
  params: [{ key: 'query', type: 'string', required: true, default: 'test' }],
  request: {
    method: 'GET',
    url: `https://api.myservice.com/v1/search?q={{query}}&key=${key('apiKey')}`,
    headers: {}
  },
  expected: 'JSON with results[]',
  commonError: '401 invalid key',
  docs: 'https://docs.myservice.com'
}
```

4. Restart server — service appears in dashboard, TOOLS.md regenerates automatically

---

## Agent Init (post-install)

Run `scripts/agent-init.sh` to configure an OpenClaw workspace:

```bash
OPENCLAW_WORKSPACE=~/.openclaw/workspace \
TOOLS_SERVER_URL=https://100.x.x.x:8443 \
TOOLS_SERVER_PASSWORD=yourpassword \
bash scripts/agent-init.sh
```

What it does:
- Writes `CONNECTORS.md` (2 permanent exceptions: curl pattern + gog CLI)
- Patches `AGENTS.md` with the 4-step intent router section (marker-based, idempotent)
- Verifies server reachability + TOOLS.md presence

Called automatically from `install.sh`. Safe to re-run.

---

## Releasing

See `RELEASE_CHECKLIST.md` — covers all 3 repos (tools-config-server, install, tools-packages), versioning, and GitHub releases.

## License

MIT — Part of the OpenClaw ecosystem
