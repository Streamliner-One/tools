# Changelog

## [0.9.5] — 2026-03-10

### Added — OpenRouter credential package

- `packages/openrouter/package.json`: New tool package for OpenRouter unified AI gateway
  - Fields: `apiKey` (required), `defaultModel` (optional, default: qwen/qwen3.5-plus), `siteUrl`, `siteName`
  - Declarative validation via `GET https://openrouter.ai/api/v1/auth/key` with Bearer token
  - Skill block: `useWhen` phrases for agent routing (openrouter, try qwen via openrouter, use openrouter model, etc.)
  - Usage template with curl example for `/v1/chat/completions` endpoint
  - Category: `ai`, icon: 🔀
- Pre-created credential entry `openrouter-1773159277741` with Streamliner branding defaults

---

## [0.9.4] - 2026-03-09

### Fixed
- Cache `/api/update/check` result for 5 minutes to prevent slow dashboard load on every page refresh (git fetch was taking ~1.3s, blocking UI render)

## [0.9.3] — 2026-03-09 (updated)

### Added — Intent Rules API (data-write triggers)

- `lib/registry.js`: Added `loadIntentRules`, `saveIntentRules`, `getIntentRule`, `upsertIntentRule`, `deleteIntentRule`
  - Rules stored in `registry.meta.intentRules` — no credentials or auth required
  - Schema: `{ id, intent, triggers[], entities[], action, target, confirmationTemplate, notes }`
- `server.js`: Four new endpoints:
  - `GET /api/intent-rules` — list all rules
  - `GET /api/intent-rules/:id` — get single rule
  - `POST /api/intent-rules` — create or update rule (upsert by id); auto-regenerates TOOLS.md
  - `DELETE /api/intent-rules/:id` — remove rule; auto-regenerates TOOLS.md
- `lib/generator.js`: New "Intent Rules (Data-Write Triggers)" section injected into TOOLS.md
  - Renders routing table + per-rule detail block
  - Marked **mandatory and non-optional** so agent cannot skip execution
  - Only appears if rules exist; section hidden when empty

### Initial rules seeded

- `flight_update` — triggers on flight change phrases → writes to `travel.json`
- `location_update` — triggers on location arrival phrases → writes to `LOCATION.md`

### Updated — Rule types: write vs behavior

- `lib/generator.js`: TOOLS.md now splits Intent Rules into two subsections:
  - **Data-Write Rules** — file updates, entities, targets, confirmation templates
  - **Behavior Rules** — response constraints, no file target needed
- `README.md`: Schema docs updated with both rule types and examples
- `heartbeat_ack` behavior rule seeded: silences heartbeat poll responses to `HEARTBEAT_OK` only

### Design rationale

Intent rules solve the "judgment lottery" problem: critical data updates (flights, contacts, location)
were being stored in Mem0 without updating canonical JSON files, causing stale data in scheduled
check-ins. Rules bypass agent judgment entirely — trigger phrase detected → file write → then respond.
Agent-writable via API, human-readable in TOOLS.md, server-persisted in registry.

---

## [0.9.2] — 2026-03-08

### Added — Groove HQ credential type (customer support / ticketing)

- `schema.js`: Groove schema with `apiToken` (Bearer, sensitive) + `baseUrl` (default `https://api.groovehq.com/v1/`)
  - `skill` block wired: `useWhen`, `intents` (ticket_list, ticket_create, ticket_reply, support_monitor), fallback
- `lib/usage.js`: Groove usage example — `GET /v1/tickets?status=open&per_page=25` with Bearer auth
  - `allowedHosts: ['api.groovehq.com']`, params with defaults, commonError, docs
- `server.js`: Groove live validator — probes `GET /v1/me`, returns `Connected as <name> (<email>)` on success
  - Handles 401/403 with specific messages

### Fixed — Credential field format normalization

- `lib/registry.js`: Added `normalizeFields()` — converts any incoming flat string `"value"` to wrapped `{value: "..."}` object
- Applied in both `createCredential()` and `updateCredential()` — consistent format guaranteed on all writes
- One-time migration: fixed existing flat-format fields in `google-workspace` and initial `groove` save
- All validators/usage examples use `fields.key?.value` pattern — now reliable for all credentials
- Exported `normalizeFields` for use in tests and migrations

---

## [0.9.1] — 2026-03-07

### Fixed — CONNECTORS.md: remove server-behavior bullets

- Removed 3 bullets from `scripts/agent-init.sh` generated `CONNECTORS.md` section:
  `primaryKey` field, package-name resolution, `usage.curl` pointer
- These document server behavior (can change), not environmental constraints (permanent)
- If they went stale, fresh installs would get confidently wrong agent instructions
- Rule: CONNECTORS.md contains only what the server *cannot* tell you

### Updated — Release checklist

- Force-push pattern for subtree divergence documented
- `versions.json` jq one-liner updates both `version` and `artifact_url`
- Install repo: clone-fresh + SSH remote switch (avoids HTTPS auth failure)
- tools-packages: API tag pattern, no clone needed
- Explicit patch release policy: batch doc-only fixes unless install behavior affected

---

## [0.9.0] — 2026-03-07

### ✨ Self-configuring intent router — agent ready on first session after install

The full intent→credential→execute chain is now zero-configuration. After install,
the agent reads TOOLS.md and knows exactly which endpoint to call, which auth header
to use, and what the common errors are — without reading any other documentation.

#### Added — Complete call templates in TOOLS.md

- `lib/usage.js`: full `getExampleDefinition()` for all 33 services
  - Every service: HTTP method, exact URL, auth header format, params+defaults, commonError, docs link
  - OAuth services (Amadeus): template directs agent to `/token` endpoint first
  - CLI-only services (gog, 1Password, Whisper): explicit "use CLI / tool X" instructions
  - Managed services (Telegram, Mem0): "use OpenClaw tool, not direct API" notes
- `lib/generator.js`: call templates now rendered into TOOLS.md per service
  - `curl` snippet (keys redacted), call params with defaults, common error hints
  - 24/24 agent-callable services covered; 0 stubs remaining
  - `buildUsageExample()` called per service block

#### Added — `generateToolsMd()` on every credential mutation

- `POST /api/credentials` (create), `PUT /api/credentials/:id` (update fields + rename),
  `DELETE /api/credentials/:id` — all trigger TOOLS.md regeneration
- TOOLS.md mtime is a reliable staleness signal: changed = credentials changed

#### Added — `scripts/agent-init.sh` — post-install agent configurator

- Writes `CONNECTORS.md` (2 permanent exceptions) with server URL/password baked in
- Patches `AGENTS.md` with the intent router section (marker-based, idempotent)
- Verifies: tools server reachable, TOOLS.md present, files written
- Called automatically from `install.sh` after server starts

#### Added — `install.sh`: `configure_agent()` step

- Detects OpenClaw workspace, calls `agent-init.sh` with correct URL + password
- Skips gracefully if workspace not found (prints manual-run hint)

#### Added — `resolvePrimaryKey()` in `server.js`

- Every `GET /api/credentials/:id` response now includes `primaryKey` field
- Normalized auth value regardless of internal field name (`apiKey`, `apiToken`, `token`, etc.)
- Agent never needs to know field name internals

#### Fixed — `getCredential()` resolves by package name

- `readwise` resolves to `readwise-1772811314235` automatically
- Agents never need to know timestamp-suffixed IDs

#### Updated — AGENTS.md

- Replaced credential notes/gotchas with clean 4-step flow:
  `check mtime → match intent → get primaryKey → execute`
- Two permanent exceptions only (web_fetch/private IP, gog CLI)
- All other guidance lives in TOOLS.md (generated) or the server

#### Updated — CONNECTORS.md

- Reduced to 37 lines: bootstrap curl pattern + gog CLI exception
- Tools server is the source of truth for everything else

### Fresh-install flow

```
bash install.sh
  → server starts, TOOLS.md generates
  → configure_agent() → agent-init.sh patches AGENTS.md + writes CONNECTORS.md
  → user fills credentials in dashboard
  → each save → validates + regenerates TOOLS.md with call templates
  → agent first session: reads TOOLS.md, checks mtime before calls, never guesses
```

---

## [0.8.7] — 2026-03-06

### Added — End-to-end integration verification

- New `verify-integrations.sh` script: tests full chain for every credential
  - Package schema + skill block check
  - Credential field validation
  - Intent router resolution
  - Usage example availability
  - Live API probe (actual HTTP calls to each service)
- Supports `--skip-live` (infrastructure-only check) and `--only <pkg>` (single service)
- 33 credentials verified, all green

### Added — Router intents for NanoBanana and Oura

- `image_generation`, `image_edit` → nanoBanana
- `sleep_data`, `health_metrics`, `readiness_check` → oura
- Previously these credentials existed but the intent router couldn't route to them

### Fixed — Todoist API v1 migration

- Todoist deprecated `rest/v2` (returns 410 Gone), migrated to `api/v1`
- Updated verify probe to use new endpoint

### Updated — Release checklist (steps 6–7)

- Added mandatory live API probe step after wiring a new credential
- Added agent delivery simulation step (full intent → router → credential → query → deliver chain)
- Documented the Readwise incident as canonical example of shipping without E2E verification
- Added note about timestamp-suffixed credential IDs for package-based credentials

## [0.8.6] — 2026-03-06

### Fixed — Package→TOOLS.md pipeline

- `generator.js` was reading stale `registry.services` instead of `credentials`
- Package-based credentials (Readwise, Obsidian-Sync) were invisible to TOOLS.md and routing
- `packages.js` now passes the `skill` block to schemas correctly

## [0.8.5] — 2026-03-06

### Fixed — Secret field safety

- Restored pre-fill for password/API-key fields on Edit (1Password-style reveal + compare)
- Added `data-original` guard: unchanged secrets are **not re-saved**, preventing silent truncation/corruption
- Confirmed no `maxlength` or server-side length limits on credential fields

## [0.8.4] — 2026-03-06

### Added — Obsidian Sync (Headless)

- New credential type: `obsidian-sync`
- OTP-only one-shot login flow from the dashboard (no terminal required)
- Optional server-managed vault paths with safe base directory
- Auto `ob sync-setup` after login when remote vault is selected
- Vault picker: remote vault list endpoint + dropdown on credential edit

### Added — Readwise API token support

- New credential type: `readwise`
- Validator confirms token via `GET /api/v2/auth/` and returns "Readwise token OK"

### Improved — Health + validation signal quality

- Clicking **Test** now invalidates cached health so refresh reflects the latest result
- Pinecone validator sends `X-Pinecone-API-Version: 2024-04` and surfaces auth rejection reason headers

### Safety

- Registry now keeps automatic versioned backups (`tools-registry-backups/`, newest 50)

## [0.8.3] — 2026-03-05

### Improved — Mem0 card UX and health feedback

- Mem0 labels simplified to `long-term-memory`
- After clicking **Test**, credential card health now updates immediately (`health: ok` / `health: fail`) without waiting for global refresh

## [0.8.2] — 2026-03-05

### Fixed — Mem0 credential validation signal quality

- Mem0 validator now probes `/v1/memories/` with optional `userId`
- Treats `400` context-required responses as **key valid** (warning) instead of ambiguous endpoint mismatch
- Keeps `401/403` as hard invalid key failures

## [0.8.1] — 2026-03-05

### Added — Mem0 as first-class credential type

- New service schema: `mem0` (Memory category)
- Dashboard fields: `apiKey`, `userId`, `orgId`, `projectId`, `mode`
- Live validator added for Mem0 API key connectivity
- Included in generated Tool Catalog routing metadata

## [0.8.0] — 2026-03-05

### Added — Gemini credential as first-class AI provider

- New infrastructure provider schema: `google` (Gemini API)
- Dedicated validator for Gemini API key (`/v1beta/models`)
- Supports separate dashboard setup/testing from Nano Banana

### Improved — OpenClaw compare/status source resolution

- `openclaw auth` compare now resolves provider source from effective OpenClaw auth state
- Supports both `profiles` and `env` origins instead of profile-file-only assumptions
- OpenAI now reports correctly when key is active via profile/env and avoids false "missing" state

## [0.7.9] — 2026-03-05

### Fixed — Update checker downgrade false-positive

- `/api/update/check` now treats update availability as **remote newer only** (semver-aware)
- Added response fields: `remoteIsNewer`, `versionComparison`, and refined `relation`
- Dashboard Update chip/modal now block downgrade prompts and correctly show "Local build is ahead" when applicable

## [0.7.8] — 2026-03-05

### Added — Dashboard push to OpenClaw auth profiles

- New status endpoint: `GET /api/openclaw/auth/status`
- New compare endpoint: `GET /api/openclaw/auth/compare/:credentialId`
- New push endpoint: `POST /api/credentials/:id/push/openclaw`
- Dashboard adds **OpenClaw** action on supported provider cards (`anthropic|openai|moonshot|google`)
- Push flow now backs up `auth-profiles.json`, writes `provider:default` API key profile, updates `lastGood`, and attempts gateway restart

### Safety gates

- Feature is disabled by default
- Enable with `TOOLS_CONFIG_OPENCLAW_PUSH=1`
- Optional overrides: `OPENCLAW_STATE_DIR`, `OPENCLAW_AGENT_ID`, `OPENCLAW_AUTH_PROFILES_PATH`, `OPENCLAW_RESTART_CMD`

## [0.7.7] — 2026-03-05

### Added — Agent discoverability

**`GET /api/agent-guide` (no auth required):**
New self-describing endpoint for AI agents. Returns: quickstart steps, all key endpoints with descriptions, intent router summary with supported intents, list of configured credential IDs, and agent tips. Available without authentication so agents can discover how to use the server before they have credentials.

**`/root/.tools-server-access` written on install:**
Installer now writes a JSON file with URL, password, version, install path, and agent-guide URL to `/root/.tools-server-access` (chmod 600). Agents and operators can always find server access details without scrolling through install logs.

## [0.7.6] — 2026-03-05

### Fixed — Pinecone integration

**Probe was a false positive:**
The health check was hitting `app.pinecone.io/actions/whoami`, which returns an HTML 200 regardless of API key validity. Any Pinecone credential always showed ✅ Connected even when the key was wrong or expired.

**Probe now hits the real data plane:**
`POST /describe_index_stats` on the actual index host. Returns vector count on success (`Connected to Pinecone • 1059 vectors in sop-docs`), and meaningful errors on failure (`403 — check API key or IP allowlist`).

**Index Host field now accepts full URLs:**
Pinecone's dashboard shows the host as `https://your-index.svc.aped-xxxx.pinecone.io`. Users can now paste this directly — the `https://` prefix is stripped automatically. No more "getaddrinfo EAI_AGAIN https" DNS errors.

**Schema updated:**
- Renamed `host` → `indexHost` (with updated placeholder showing full URL format)
- Added `indexName` field
- Removed stale `environment` field from required set

**Usage example added:**
`lib/usage.js` now includes a runnable Pinecone example (`describe_index_stats`) with correct headers, expected response shape, and common error guidance.

---

## [0.7.5] — 2026-03-01

- 1Password agent-callable (service account, skill block)
- Full VPS installer validated on fresh Hetzner VM
- Health dashboard with OAuth token expiry tracking
