# Release Checklist — tools-config-server

Follow every step in order. Verify at the end before declaring done.

## Steps

1. Bump version in `tools-server/package.json`
2. Update `tools-server/CHANGELOG.md` with new entry
3. Commit: `git add tools-server/package.json tools-server/CHANGELOG.md tools-server/server.js && git commit -m "tools-server vX.Y.Z: <description>"`
4. Push to mel-memory: `git push origin master`
5. Tag: `git tag vX.Y.Z && git push origin vX.Y.Z`
6. Subtree push to Streamliner: `git subtree push --prefix=tools-server streamliner main`
7. Create GitHub Release on `Streamliner-One/tools-config-server` via API (⚠️ tags do NOT transfer via subtree push — must be created explicitly)
8. Build artifact: `tar -czf tools-config-server-X.Y.Z.tar.gz --exclude=node_modules --exclude=certs --exclude=server.log --exclude=tools-registry.json --exclude=.health-cache.json tools-server/`
9. Upload artifact to `Streamliner-One/tools` → `artifacts/tools-config-server-X.Y.Z.tar.gz`
10. Update `Streamliner-One/tools` → `versions.json` (both `stable` and `latest` channels — version AND artifact_url)
11. Update `Streamliner-One/tools` → `README.md` channels table (both `stable` and `latest` rows) to match new version
    - Use targeted sed: `sed -i "s/| \`stable\` | [0-9.]* |/| \`stable\` | X.X.Y |/" README.md` (and same for `latest`)
    - ⚠️ Do NOT use a blanket version replace — it clobbers artifact URLs and other refs
12. Create GitHub Release on `Streamliner-One/tools`
13. Create GitHub Release on `Streamliner-One/tools-packages`

## Mandatory Verification

Run this and confirm all three show the new version before declaring done:

```bash
COOKIE=$(mktemp); trap "rm -f $COOKIE" EXIT
curl -sk -c "$COOKIE" -X POST https://100.84.57.51:8443/api/login \
  -H 'Content-Type: application/json' -d '{"password":"mel2026"}' >/dev/null
GH_TOKEN=$(curl -sk -b "$COOKIE" https://100.84.57.51:8443/api/credentials/github | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('primaryKey',''))")

for repo in "Streamliner-One/tools-config-server" "Streamliner-One/tools" "Streamliner-One/tools-packages"; do
  curl -s "https://api.github.com/repos/$repo/releases/latest" \
    -H "Authorization: Bearer $GH_TOKEN" | python3 -c "import sys,json; d=json.load(sys.stdin); print('$repo:', d.get('tag_name'))"
done
```

All three must match the new version. If any shows the old version — fix before declaring done.

Also verify README channels table is updated:
```bash
curl -s https://raw.githubusercontent.com/Streamliner-One/tools/main/README.md | grep -A3 "## Channels"
# Expected: both stable and latest showing the new version
```

## Never Stage
`.health-cache.json`, `server.log`, `update-run.log`, `tools-registry.json`, `node_modules/`, `certs/`
