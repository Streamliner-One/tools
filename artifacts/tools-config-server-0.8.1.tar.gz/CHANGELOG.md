# Changelog

## [0.8.1] — 2026-03-05

### Added — Mem0 as first-class credential type

- New service schema: `mem0` (Memory category)
- Dashboard fields: `apiKey`, `userId`, `orgId`, `projectId`, `mode`
- Live validator added for Mem0 API key connectivity
- Included in generated Tool Catalog routing metadata

## [0.8.0] — 2026-03-05

### Added — Gemini credential as first-class AI provider

- New infrastructure provider schema: `google` (Gemini API)
- Dedicated validator for Gemini API key (`/v1beta/models`)
- Supports separate dashboard setup/testing from Nano Banana

### Improved — OpenClaw compare/status source resolution

- `openclaw auth` compare now resolves provider source from effective OpenClaw auth state
- Supports both `profiles` and `env` origins instead of profile-file-only assumptions
- OpenAI now reports correctly when key is active via profile/env and avoids false "missing" state

## [0.7.9] — 2026-03-05

### Fixed — Update checker downgrade false-positive

- `/api/update/check` now treats update availability as **remote newer only** (semver-aware)
- Added response fields: `remoteIsNewer`, `versionComparison`, and refined `relation`
- Dashboard Update chip/modal now block downgrade prompts and correctly show "Local build is ahead" when applicable

## [0.7.8] — 2026-03-05

### Added — Dashboard push to OpenClaw auth profiles

- New status endpoint: `GET /api/openclaw/auth/status`
- New compare endpoint: `GET /api/openclaw/auth/compare/:credentialId`
- New push endpoint: `POST /api/credentials/:id/push/openclaw`
- Dashboard adds **OpenClaw** action on supported provider cards (`anthropic|openai|moonshot|google`)
- Push flow now backs up `auth-profiles.json`, writes `provider:default` API key profile, updates `lastGood`, and attempts gateway restart

### Safety gates

- Feature is disabled by default
- Enable with `TOOLS_CONFIG_OPENCLAW_PUSH=1`
- Optional overrides: `OPENCLAW_STATE_DIR`, `OPENCLAW_AGENT_ID`, `OPENCLAW_AUTH_PROFILES_PATH`, `OPENCLAW_RESTART_CMD`

## [0.7.7] — 2026-03-05

### Added — Agent discoverability

**`GET /api/agent-guide` (no auth required):**
New self-describing endpoint for AI agents. Returns: quickstart steps, all key endpoints with descriptions, intent router summary with supported intents, list of configured credential IDs, and agent tips. Available without authentication so agents can discover how to use the server before they have credentials.

**`/root/.tools-server-access` written on install:**
Installer now writes a JSON file with URL, password, version, install path, and agent-guide URL to `/root/.tools-server-access` (chmod 600). Agents and operators can always find server access details without scrolling through install logs.

## [0.7.6] — 2026-03-05

### Fixed — Pinecone integration

**Probe was a false positive:**
The health check was hitting `app.pinecone.io/actions/whoami`, which returns an HTML 200 regardless of API key validity. Any Pinecone credential always showed ✅ Connected even when the key was wrong or expired.

**Probe now hits the real data plane:**
`POST /describe_index_stats` on the actual index host. Returns vector count on success (`Connected to Pinecone • 1059 vectors in sop-docs`), and meaningful errors on failure (`403 — check API key or IP allowlist`).

**Index Host field now accepts full URLs:**
Pinecone's dashboard shows the host as `https://your-index.svc.aped-xxxx.pinecone.io`. Users can now paste this directly — the `https://` prefix is stripped automatically. No more "getaddrinfo EAI_AGAIN https" DNS errors.

**Schema updated:**
- Renamed `host` → `indexHost` (with updated placeholder showing full URL format)
- Added `indexName` field
- Removed stale `environment` field from required set

**Usage example added:**
`lib/usage.js` now includes a runnable Pinecone example (`describe_index_stats`) with correct headers, expected response shape, and common error guidance.

---

## [0.7.5] — 2026-03-01

- 1Password agent-callable (service account, skill block)
- Full VPS installer validated on fresh Hetzner VM
- Health dashboard with OAuth token expiry tracking
