#!/bin/bash
pkill -9 -f "node.*server" 2>/dev/null
sleep 1
cd /home/alex/.openclaw/workspace/tools-server
node server.js --bind 100.84.57.51:8443 --https --password mel2026 &
echo $! > /tmp/server.pid
sleep 3
echo "Server started"
curl -s -k -o /dev/null -w "HTTP: %{http_code}\n" https://100.84.57.51:8443/login.html