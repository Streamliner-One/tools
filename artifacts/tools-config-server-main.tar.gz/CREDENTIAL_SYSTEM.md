# Credential System Architecture

## Overview
n8n-style credentials: Multiple named instances per connector type.

## Data Model

### Before (Single Instance)
```json
{
  "services": {
    "stripe": {
      "enabled": true,
      "fields": { "apiKey": "sk_live_..." }
    }
  }
}
```

### After (Multiple Named Instances)
```json
{
  "credentials": {
    "stripe-prod": {
      "_package": "stripe",
      "_name": "Stripe - Production",
      "fields": { "apiKey": "sk_live_..." }
    },
    "stripe-test": {
      "_package": "stripe", 
      "_name": "Stripe - Test Mode",
      "fields": { "apiKey": "sk_test_..." }
    }
  }
}
```

## API Endpoints

### `POST /api/credentials`
Create new credential instance.
```json
{
  "packageId": "stripe",
  "name": "Stripe - Production",
  "fields": { "apiKey": "sk_live_..." }
}
```

### `PUT /api/credentials/:id/rename`
Rename credential.
```json
{ "name": "Stripe - New Name" }
```

### `DELETE /api/credentials/:id`
Delete credential instance.

### `POST /api/credentials/:id/validate`
Test credential connection.

## UI Flow

1. **Dashboard** shows credential list:
   - Grouped by package type (Stripe, Notion, etc.)
   - Each instance: Icon + Custom Name + Edit/Delete
   - "➕ Add Credential" button

2. **Add Credential Modal**:
   - Select package type (dropdown)
   - Enter custom name
   - Fill fields
   - Test & Save

3. **Edit Credential**:
   - Rename (inline or modal)
   - Update fields
   - Re-test

## Migration

Old `services` → New `credentials`:
- Each enabled service becomes a credential
- Name defaults to package name
- Maintains backward compatibility

## Benefits

- ✅ Multiple accounts (Stripe prod/test)
- ✅ Multiple workspaces (Notion work/personal)
- ✅ Clear naming in UI
- ✅ Agent references by name
- ✅ Familiar n8n pattern

## Future Updates

Credential packages can be updated via:
- File upload (Phase 4)
- Pull from streamliner.one
- Manual JSON editing
- Auto-update mechanism (future)