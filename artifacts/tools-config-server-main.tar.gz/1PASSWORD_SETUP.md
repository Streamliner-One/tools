# 1Password Service Account Integration

## Overview

Use 1Password service account tokens for secure, headless credential access on VPS/servers without the 1Password desktop app.

## Setup Checklist

### 1. Create Service Account
- Go to https://my.1password.com/settings/security/tokens
- Create token scoped to vaults OpenClaw needs
- **Save token immediately** (shown only once)

### 2. Store Token in Tools Config

Add to Tools Config dashboard:
```
🔐 1Password
  Service Account Token: ops_eyJ...
  Default Vault: Alex-Mel
```

### 3. System Requirements

**Install op CLI v2.18.0+:**
```bash
# macOS
brew install 1password-cli

# Linux
wget https://cache.agilebits.com/dist/1P/op2/pkg/v2.18.0/op_linux_amd64_v2.18.0.zip
sudo mv op /usr/local/bin/
```

### 4. How It Works

**Tools Config Server:**
1. Stores service account token locally
2. When validating/using:
   - Sets `OP_SERVICE_ACCOUNT_TOKEN` environment variable
   - Clears `~/.config/op` to avoid device ID conflicts
   - Runs `op vault list` or `op item get`
3. Returns credentials to agent

**Agent Usage:**
```javascript
// 1. Get 1Password config from Tools Config
const onepw = await fetch('/api/credentials/1password-xxx').then(r => r.json());
const token = onepw.fields.serviceAccountToken.value;

// 2. Use with op CLI
const { stdout } = await exec('op item get "Stripe API" --field credential', {
  env: { OP_SERVICE_ACCOUNT_TOKEN: token }
});

// 3. Store retrieved credential locally
await fetch('/api/credentials', {
  method: 'POST',
  body: JSON.stringify({
    packageId: 'stripe',
    name: 'Stripe - Production',
    fields: { secretKey: { value: stdout.trim() } }
  })
});
```

### 5. Troubleshooting

**"Signin credentials are not compatible" error:**
```bash
rm -rf ~/.config/op
# Then retry
```

**Device ID conflict:**
- Ensure no `OP_CONNECT_HOST` or `OP_CONNECT_TOKEN` env vars are set
- These take precedence over `OP_SERVICE_ACCOUNT_TOKEN`

### 6. Security Notes

- Service account token is long-lived (no expiration)
- Scoped to specific vaults only
- Stored encrypted in Tools Config registry
- Never logged or exposed in responses
- Rotate token periodically via 1Password admin

## Architecture

```
┌─────────────────┐     ┌──────────────────┐     ┌─────────────────┐
│ Tools Config    │────▶│ 1Password Cloud  │────▶│ Agent retrieves │
│ Server          │     │ (via op CLI)     │     │ credentials     │
│                 │     │                  │     │                 │
│ Service Account │     │ OP_SERVICE_ACCT  │     │ Stores locally  │
│ Token (ops_...) │     │ _TOKEN env var   │     │ in registry     │
└─────────────────┘     └──────────────────┘     └─────────────────┘
```

## Example: Bootstrap Workflow

1. **User** creates service account token in 1Password
2. **User** adds token to Tools Config (1Password credential type)
3. **Agent** retrieves token via API
4. **Agent** uses op CLI to fetch Stripe API key from 1Password
5. **Agent** stores Stripe key locally as new credential
6. **Agent** can now use Stripe without 1Password dependency

This gives you:
- ✅ Secure initial credential retrieval
- ✅ Local storage for reliability
- ✅ No runtime dependency on 1Password availability