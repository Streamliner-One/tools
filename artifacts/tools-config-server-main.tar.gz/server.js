#!/usr/bin/env node

const express = require('express');
const bcrypt = require('bcrypt');
const cookieParser = require('cookie-parser');
const helmet = require('helmet');
const https = require('https');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const { SERVICE_SCHEMAS, AGENT_SCHEMA } = require('./schema');

// Merge agent schema into service schemas
SERVICE_SCHEMAS[AGENT_SCHEMA.id] = AGENT_SCHEMA;

// Load tool packages (Phase 1: static JSON packages)
const { loadAllPackages, getPackageSchemas, getPackageValidators } = require('./lib/packages');
const loadedPackages = loadAllPackages();

// Merge package schemas into service schemas
const packageSchemas = getPackageSchemas();
for (const [id, schema] of Object.entries(packageSchemas)) {
  SERVICE_SCHEMAS[id] = schema;
}
const { loadRegistry, saveRegistry, getService, updateService, toggleService, listServices, getCredential, createCredential, updateCredential, deleteCredential, listCredentials, listCredentialsByPackage, REGISTRY_PATH } = require('./lib/registry');
const { generateToolsMd } = require('./lib/generator');

const app = express();
const SESSION_COOKIE = 'tools_session';
const SESSIONS = new Map();

// Parse arguments
function parseArgs() {
  const args = process.argv.slice(2);
  const config = {
    bind: '127.0.0.1:8080',
    password: null,
    temp: null,
    https: false,
    dataDir: path.join(process.env.HOME || '/tmp', '.openclaw/workspace')
  };

  for (let i = 0; i < args.length; i++) {
    switch (args[i]) {
      case '--bind':
        config.bind = args[++i];
        break;
      case '--password':
        config.password = args[++i];
        break;
      case '--temp':
        config.temp = parseInt(args[++i]) || 30;
        break;
      case '--https':
        config.https = true;
        break;
      case '--data-dir':
        config.dataDir = args[++i];
        break;
    }
  }

  if (!config.password) {
    config.password = crypto.randomBytes(16).toString('hex');
    console.log(`Generated password: ${config.password}`);
  }

  return config;
}

const CONFIG = parseArgs();

// Middleware
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      scriptSrc: ["'self'", "'unsafe-inline'"],
      scriptSrcAttr: ["'unsafe-inline'"],
      imgSrc: ["'self'", "data:"],
    }
  }
}));
app.use(express.json());
app.use(cookieParser());

// Auth middleware
function requireAuth(req, res, next) {
  const sessionId = req.cookies[SESSION_COOKIE];
  if (sessionId && SESSIONS.has(sessionId)) {
    const session = SESSIONS.get(sessionId);
    if (session.expires > Date.now()) {
      req.session = session;
      return next();
    }
    SESSIONS.delete(sessionId);
  }
  res.status(401).json({ error: 'Unauthorized' });
}

function requireAuthPage(req, res, next) {
  const sessionId = req.cookies[SESSION_COOKIE];
  if (sessionId && SESSIONS.has(sessionId)) {
    const session = SESSIONS.get(sessionId);
    if (session.expires > Date.now()) {
      req.session = session;
      return next();
    }
    SESSIONS.delete(sessionId);
  }
  res.redirect('/login.html');
}

// Routes
app.post('/api/login', async (req, res) => {
  const { password } = req.body;
  const hashed = await bcrypt.hash(CONFIG.password, 10);
  const match = await bcrypt.compare(password, hashed);
  
  if (password === CONFIG.password || match) {
    const sessionId = crypto.randomUUID();
    SESSIONS.set(sessionId, { 
      created: Date.now(),
      expires: Date.now() + (24 * 60 * 60 * 1000) // 24h
    });
    res.cookie(SESSION_COOKIE, sessionId, { httpOnly: true, secure: CONFIG.https, sameSite: 'lax' });
    res.json({ success: true });
  } else {
    res.status(401).json({ error: 'Invalid password' });
  }
});

app.post('/api/logout', (req, res) => {
  const sessionId = req.cookies[SESSION_COOKIE];
  if (sessionId) SESSIONS.delete(sessionId);
  res.clearCookie(SESSION_COOKIE);
  res.json({ success: true });
});

// Protected API routes
app.get('/api/services', requireAuth, (req, res) => {
  const registry = loadRegistry();
  const services = [];
  
  for (const [id, schema] of Object.entries(SERVICE_SCHEMAS)) {
    const configured = registry.services[id] || { enabled: false, fields: {} };
    services.push({
      id,
      ...schema,
      enabled: configured.enabled || false,
      configuredFields: Object.keys(configured.fields || {})
    });
  }
  
  res.json({ services });
});

app.get('/api/services/:id', requireAuth, (req, res) => {
  const { id } = req.params;
  const schema = SERVICE_SCHEMAS[id];
  if (!schema) return res.status(404).json({ error: 'Service not found' });
  
  const service = getService(id);
  res.json({
    schema,
    config: service
  });
});

app.post('/api/services/:id', requireAuth, (req, res) => {
  const { id } = req.params;
  const { enabled, fields } = req.body;
  
  const schema = SERVICE_SCHEMAS[id];
  if (!schema) return res.status(404).json({ error: 'Service not found' });
  
  const update = {};
  if (typeof enabled === 'boolean') update.enabled = enabled;
  if (fields) update.fields = fields;
  
  const result = updateService(id, update);
  generateToolsMd();
  
  res.json({ success: true, service: result });
});

app.post('/api/services/:id/toggle', requireAuth, (req, res) => {
  const { id } = req.params;
  const { enabled } = req.body;
  
  const result = toggleService(id, enabled);
  generateToolsMd();
  
  res.json({ success: true, service: result });
});

// Live validation with test buttons
const VALIDATORS = {
  notion: async (fields) => {
    const apiKey = fields.apiKey?.value;
    if (!apiKey) return { valid: false, message: 'API Key required' };
    
    try {
      const https = require('https');
      const response = await new Promise((resolve, reject) => {
        const req = https.request('https://api.notion.com/v1/users/me', {
          method: 'GET',
          headers: {
            'Authorization': `Bearer ${apiKey}`,
            'Notion-Version': '2022-06-28'
          }
        }, (res) => {
          let data = '';
          res.on('data', chunk => data += chunk);
          res.on('end', () => resolve({ status: res.statusCode, data }));
        });
        req.on('error', reject);
        req.setTimeout(10000, () => reject(new Error('Timeout')));
        req.end();
      });
      
      if (response.status === 200) {
        const json = JSON.parse(response.data);
        return { valid: true, message: `Connected as ${json.name || json.bot?.owner?.user?.name || 'Notion workspace'}` };
      } else if (response.status === 401) {
        return { valid: false, message: 'Invalid API key (401)' };
      } else {
        return { valid: false, message: `HTTP ${response.status}` };
      }
    } catch (err) {
      return { valid: false, message: err.message };
    }
  },
  
  todoist: async (fields) => {
    const token = fields.apiToken?.value;
    if (!token) return { valid: false, message: 'API Token required' };
    
    try {
      const https = require('https');
      const response = await new Promise((resolve, reject) => {
        const req = https.request('https://api.todoist.com/api/v1/projects', {
          method: 'GET',
          headers: { 'Authorization': `Bearer ${token}` }
        }, (res) => {
          let data = '';
          res.on('data', chunk => data += chunk);
          res.on('end', () => resolve({ status: res.statusCode }));
        });
        req.on('error', reject);
        req.setTimeout(10000, () => reject(new Error('Timeout')));
        req.end();
      });
      
      if (response.status === 200) {
        return { valid: true, message: 'Connected to Todoist' };
      } else if (response.status === 401) {
        return { valid: false, message: 'Invalid token (401)' };
      } else {
        return { valid: false, message: `HTTP ${response.status}` };
      }
    } catch (err) {
      return { valid: false, message: err.message };
    }
  },
  
  telegram: async (fields) => {
    const token = fields.botToken?.value;
    if (!token) return { valid: false, message: 'Bot Token required' };
    
    try {
      const https = require('https');
      const response = await new Promise((resolve, reject) => {
        const req = https.request(`https://api.telegram.org/bot${token}/getMe`, {
          method: 'GET'
        }, (res) => {
          let data = '';
          res.on('data', chunk => data += chunk);
          res.on('end', () => resolve({ status: res.statusCode, data }));
        });
        req.on('error', reject);
        req.setTimeout(10000, () => reject(new Error('Timeout')));
        req.end();
      });
      
      if (response.status === 200) {
        const json = JSON.parse(response.data);
        if (json.ok) {
          return { valid: true, message: `@${json.result.username} (${json.result.first_name})` };
        }
        return { valid: false, message: json.description || 'Invalid token' };
      } else if (response.status === 401) {
        return { valid: false, message: 'Invalid bot token (401)' };
      } else {
        return { valid: false, message: `HTTP ${response.status}` };
      }
    } catch (err) {
      return { valid: false, message: err.message };
    }
  },
  
  openai: async (fields) => {
    const apiKey = fields.apiKey?.value;
    if (!apiKey) return { valid: false, message: 'API Key required' };
    
    try {
      const https = require('https');
      const response = await new Promise((resolve, reject) => {
        const req = https.request('https://api.openai.com/v1/models', {
          method: 'GET',
          headers: { 'Authorization': `Bearer ${apiKey}` }
        }, (res) => {
          let data = '';
          res.on('data', chunk => data += chunk);
          res.on('end', () => resolve({ status: res.statusCode, data }));
        });
        req.on('error', reject);
        req.setTimeout(10000, () => reject(new Error('Timeout')));
        req.end();
      });
      
      if (response.status === 200) {
        const json = JSON.parse(response.data);
        return { valid: true, message: `${json.data?.length || 0} models available` };
      } else if (response.status === 401) {
        return { valid: false, message: 'Invalid API key (401)' };
      } else if (response.status === 429) {
        return { valid: true, warning: true, message: 'Rate limited (429) - key valid but over quota' };
      } else {
        return { valid: false, message: `HTTP ${response.status}` };
      }
    } catch (err) {
      return { valid: false, message: err.message };
    }
  },
  
  anthropic: async (fields) => {
    const apiKey = fields.apiKey?.value;
    if (!apiKey) return { valid: false, message: 'API Key required' };
    
    try {
      const https = require('https');
      const response = await new Promise((resolve, reject) => {
        const req = https.request('https://api.anthropic.com/v1/models', {
          method: 'GET',
          headers: { 
            'x-api-key': apiKey,
            'anthropic-version': '2023-06-01'
          }
        }, (res) => {
          let data = '';
          res.on('data', chunk => data += chunk);
          res.on('end', () => resolve({ status: res.statusCode, data }));
        });
        req.on('error', reject);
        req.setTimeout(10000, () => reject(new Error('Timeout')));
        req.end();
      });
      
      if (response.status === 200) {
        return { valid: true, message: 'Connected to Anthropic' };
      } else if (response.status === 401) {
        return { valid: false, message: 'Invalid API key (401)' };
      } else {
        return { valid: false, message: `HTTP ${response.status}` };
      }
    } catch (err) {
      return { valid: false, message: err.message };
    }
  },
  
  moonshot: async (fields) => {
    const apiKey = fields.apiKey?.value;
    if (!apiKey) return { valid: false, message: 'API Key required' };
    
    try {
      const https = require('https');
      const response = await new Promise((resolve, reject) => {
        const req = https.request('https://api.moonshot.ai/v1/models', {
          method: 'GET',
          headers: { 'Authorization': `Bearer ${apiKey}` }
        }, (res) => {
          let data = '';
          res.on('data', chunk => data += chunk);
          res.on('end', () => resolve({ status: res.statusCode }));
        });
        req.on('error', reject);
        req.setTimeout(10000, () => reject(new Error('Timeout')));
        req.end();
      });
      
      if (response.status === 200) {
        return { valid: true, message: 'Connected to Moonshot' };
      } else if (response.status === 401) {
        return { valid: false, message: 'Invalid API key (401)' };
      } else {
        return { valid: false, message: `HTTP ${response.status}` };
      }
    } catch (err) {
      return { valid: false, message: err.message };
    }
  },
  
  elevenlabs: async (fields) => {
    const apiKey = fields.apiKey?.value;
    if (!apiKey) return { valid: false, message: 'API Key required' };
    
    try {
      const https = require('https');
      const response = await new Promise((resolve, reject) => {
        const req = https.request('https://api.elevenlabs.io/v1/voices', {
          method: 'GET',
          headers: { 'xi-api-key': apiKey }
        }, (res) => {
          let data = '';
          res.on('data', chunk => data += chunk);
          res.on('end', () => resolve({ status: res.statusCode, data }));
        });
        req.on('error', reject);
        req.setTimeout(10000, () => reject(new Error('Timeout')));
        req.end();
      });
      
      if (response.status === 200) {
        const json = JSON.parse(response.data);
        const voiceCount = json.voices?.length || 0;
        return { valid: true, message: `${voiceCount} voices available` };
      } else if (response.status === 401) {
        return { valid: false, message: 'Invalid API key (401)' };
      } else {
        return { valid: false, message: `HTTP ${response.status}` };
      }
    } catch (err) {
      return { valid: false, message: err.message };
    }
  },
  
  perplexity: async (fields) => {
    const apiKey = fields.apiKey?.value;
    if (!apiKey) return { valid: false, message: 'API Key required' };
    
    try {
      const https = require('https');
      const response = await new Promise((resolve, reject) => {
        const req = https.request('https://api.perplexity.ai/chat/completions', {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${apiKey}`,
            'Content-Type': 'application/json'
          }
        }, (res) => {
          let data = '';
          res.on('data', chunk => data += chunk);
          res.on('end', () => resolve({ status: res.statusCode, data }));
        });
        req.on('error', reject);
        req.setTimeout(10000, () => reject(new Error('Timeout')));
        req.write(JSON.stringify({
          model: 'sonar',
          messages: [{ role: 'user', content: 'Hello' }],
          max_tokens: 1
        }));
        req.end();
      });
      
      // 400 with empty message is OK (API is working, just needs valid prompt)
      if (response.status === 200 || response.status === 400) {
        return { valid: true, message: 'Connected to Perplexity' };
      } else if (response.status === 401) {
        return { valid: false, message: 'Invalid API key (401)' };
      } else {
        return { valid: false, message: `HTTP ${response.status}` };
      }
    } catch (err) {
      return { valid: false, message: err.message };
    }
  },
  
  goplaces: async (fields) => {
    const apiKey = fields.apiKey?.value;
    if (!apiKey) return { valid: false, message: 'API Key required' };
    
    return { valid: null, message: 'Google Places validation requires POST request - configure and test via skill' };
  },
  
  newsapi: async (fields) => {
    const apiKey = fields.apiKey?.value;
    if (!apiKey) return { valid: false, message: 'API Key required' };
    
    try {
      const https = require('https');
      const response = await new Promise((resolve, reject) => {
        const req = https.request(`https://newsapi.org/v2/top-headlines?country=us&pageSize=1&apiKey=${apiKey}`, {
          method: 'GET',
          headers: {
            'User-Agent': 'OpenClawTools/1.0'
          }
        }, (res) => {
          let data = '';
          res.on('data', chunk => data += chunk);
          res.on('end', () => resolve({ status: res.statusCode, data }));
        });
        req.on('error', reject);
        req.setTimeout(10000, () => reject(new Error('Timeout')));
        req.end();
      });
      
      if (response.status === 200) {
        return { valid: true, message: 'Connected to NewsAPI' };
      } else if (response.status === 401) {
        return { valid: false, message: 'Invalid API key (401)' };
      } else {
        const json = JSON.parse(response.data);
        return { valid: false, message: json.message || `HTTP ${response.status}` };
      }
    } catch (err) {
      return { valid: false, message: err.message };
    }
  },
  
  duffel: async (fields) => {
    const apiKey = fields.apiKey?.value;
    if (!apiKey) return { valid: false, message: 'API Key required' };
    
    try {
      const https = require('https');
      const response = await new Promise((resolve, reject) => {
        const req = https.request('https://api.duffel.com/air/offer_requests', {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${apiKey}`,
            'Duffel-Version': 'v2',
            'Content-Type': 'application/json'
          }
        }, (res) => {
          let data = '';
          res.on('data', chunk => data += chunk);
          res.on('end', () => resolve({ status: res.statusCode }));
        });
        req.on('error', reject);
        req.setTimeout(10000, () => reject(new Error('Timeout')));
        req.write(JSON.stringify({
          data: {
            slices: [],
            passengers: []
          }
        }));
        req.end();
      });
      
      // 422 is expected with empty slices (API is working)
      if (response.status === 422 || response.status === 200) {
        return { valid: true, message: 'Connected to Duffel (sandbox)' };
      } else if (response.status === 401) {
        return { valid: false, message: 'Invalid API key (401)' };
      } else {
        return { valid: false, message: `HTTP ${response.status}` };
      }
    } catch (err) {
      return { valid: false, message: err.message };
    }
  },
  
  weather: async (fields) => {
    const provider = fields.provider?.value || 'open-meteo';
    if (provider === 'open-meteo') {
      return { valid: true, message: 'Open-Meteo requires no API key' };
    }
    return { valid: null, message: 'OpenWeatherMap validation not implemented' };
  },
  
  n8n: async (fields) => {
    const hostUrl = fields.hostUrl?.value;
    const apiKey = fields.apiKey?.value;
    
    if (!hostUrl) return { valid: false, message: 'Host URL required' };
    
    try {
      const https = require('https');
      const url = new URL(hostUrl);
      const response = await new Promise((resolve, reject) => {
        const req = https.request(`${hostUrl}/api/v1/workflows`, {
          method: 'GET',
          headers: apiKey ? { 'X-N8N-API-KEY': apiKey } : {}
        }, (res) => {
          let data = '';
          res.on('data', chunk => data += chunk);
          res.on('end', () => resolve({ status: res.statusCode }));
        });
        req.on('error', reject);
        req.setTimeout(10000, () => reject(new Error('Timeout')));
        req.end();
      });
      
      if (response.status === 200) {
        return { valid: true, message: 'Connected to n8n' };
      } else if (response.status === 401) {
        return { valid: false, message: 'Invalid API key (401)' };
      } else {
        return { valid: false, message: `HTTP ${response.status}` };
      }
    } catch (err) {
      return { valid: false, message: err.message };
    }
  },
  
  '17track': async (fields) => {
    const apiKey = fields.apiKey?.value;
    if (!apiKey) return { valid: false, message: 'API Key required' };
    
    try {
      const https = require('https');
      const response = await new Promise((resolve, reject) => {
        const req = https.request('https://api.17track.net/track/v2.2/gettrackinfo', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            '17token': apiKey
          }
        }, (res) => {
          let data = '';
          res.on('data', chunk => data += chunk);
          res.on('end', () => resolve({ status: res.statusCode, data }));
        });
        req.on('error', reject);
        req.setTimeout(10000, () => reject(new Error('Timeout')));
        req.write(JSON.stringify([{ number: 'TEST123456' }]));
        req.end();
      });
      
      // 401 = invalid key, 400/404 = key valid but tracking number not found
      if (response.status === 401) {
        return { valid: false, message: 'Invalid API key (401)' };
      }
      return { valid: true, message: 'Connected to 17TRACK' };
    } catch (err) {
      return { valid: false, message: err.message };
    }
  },
  
  aviationstack: async (fields) => {
    const apiKey = fields.apiKey?.value;
    if (!apiKey) return { valid: false, message: 'API Key required' };
    
    try {
      const https = require('https');
      const response = await new Promise((resolve, reject) => {
        const req = https.request(`https://api.aviationstack.com/v1/flights?access_key=${apiKey}&limit=1`, {
          method: 'GET'
        }, (res) => {
          let data = '';
          res.on('data', chunk => data += chunk);
          res.on('end', () => resolve({ status: res.statusCode, data }));
        });
        req.on('error', reject);
        req.setTimeout(10000, () => reject(new Error('Timeout')));
        req.end();
      });
      
      if (response.status === 200) {
        const json = JSON.parse(response.data);
        if (json.error?.code === 'invalid_access_key') {
          return { valid: false, message: 'Invalid API key' };
        }
        return { valid: true, message: 'Connected to Aviationstack' };
      } else {
        return { valid: false, message: `HTTP ${response.status}` };
      }
    } catch (err) {
      return { valid: false, message: err.message };
    }
  },
  
  amadeus: async (fields) => {
    const clientId = fields.clientId?.value;
    const clientSecret = fields.clientSecret?.value;
    const environment = fields.environment?.value || 'production';
    
    if (!clientId || !clientSecret) {
      return { valid: false, message: 'Client ID and Secret required' };
    }
    
    try {
      const https = require('https');
      const baseUrl = environment === 'production' ? 'api.amadeus.com' : 'api.amadeus.com'; // Same for OAuth endpoint
      
      const response = await new Promise((resolve, reject) => {
        const req = https.request(`https://${baseUrl}/v1/security/oauth2/token`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
          }
        }, (res) => {
          let data = '';
          res.on('data', chunk => data += chunk);
          res.on('end', () => resolve({ status: res.statusCode, data }));
        });
        req.on('error', reject);
        req.setTimeout(10000, () => reject(new Error('Timeout')));
        req.write(`grant_type=client_credentials&client_id=${clientId}&client_secret=${clientSecret}`);
        req.end();
      });
      
      if (response.status === 200) {
        return { valid: true, message: `Connected to Amadeus (${environment})` };
      } else if (response.status === 401) {
        return { valid: false, message: 'Invalid credentials (401)' };
      } else {
        return { valid: false, message: `HTTP ${response.status}` };
      }
    } catch (err) {
      return { valid: false, message: err.message };
    }
  },
  
  goplaces: async (fields) => {
    const apiKey = fields.apiKey?.value;
    if (!apiKey) return { valid: false, message: 'API Key required' };
    
    try {
      const https = require('https');
      const response = await new Promise((resolve, reject) => {
        const req = https.request('https://places.googleapis.com/v1/places:searchText', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'X-Goog-Api-Key': apiKey,
            'X-Goog-FieldMask': 'places.displayName'
          }
        }, (res) => {
          let data = '';
          res.on('data', chunk => data += chunk);
          res.on('end', () => resolve({ status: res.statusCode, data }));
        });
        req.on('error', reject);
        req.setTimeout(10000, () => reject(new Error('Timeout')));
        req.write(JSON.stringify({ textQuery: 'test', maxResultCount: 1 }));
        req.end();
      });
      
      // 400 = valid key but bad request, 401/403 = invalid key
      if (response.status === 400) {
        return { valid: true, message: 'Connected to Google Places (New)' };
      } else if (response.status === 401 || response.status === 403) {
        return { valid: false, message: 'Invalid API key' };
      }
      return { valid: true, message: 'Connected to Google Places' };
    } catch (err) {
      return { valid: false, message: err.message };
    }
  },
  
  openexchangerates: async (fields) => {
    const apiKey = fields.apiKey?.value;
    if (!apiKey) return { valid: false, message: 'API Key required' };
    
    try {
      const https = require('https');
      const response = await new Promise((resolve, reject) => {
        const req = https.request(`https://openexchangerates.org/api/latest.json?app_id=${apiKey}`, {
          method: 'GET'
        }, (res) => {
          let data = '';
          res.on('data', chunk => data += chunk);
          res.on('end', () => resolve({ status: res.statusCode, data }));
        });
        req.on('error', reject);
        req.setTimeout(10000, () => reject(new Error('Timeout')));
        req.end();
      });
      
      if (response.status === 200) {
        return { valid: true, message: 'Connected to Open Exchange Rates' };
      } else if (response.status === 401) {
        const json = JSON.parse(response.data);
        return { valid: false, message: json.message || 'Invalid API key (401)' };
      } else {
        return { valid: false, message: `HTTP ${response.status}` };
      }
    } catch (err) {
      return { valid: false, message: err.message };
    }
  },
  
  oura: async (fields) => {
    const clientId = fields.clientId?.value;
    const clientSecret = fields.clientSecret?.value;
    
    if (!clientId || !clientSecret) {
      return { valid: false, message: 'Client ID and Secret required' };
    }
    
    // Oura uses OAuth2 - validation would require token exchange
    // For now, just check credentials are present
    return { valid: null, message: 'Oura uses OAuth2 (configured in n8n). Credentials stored.' };
  },
  
  brave: async (fields) => {
    const apiKey = fields.apiKey?.value;
    if (!apiKey) return { valid: false, message: 'API Key required' };
    
    try {
      const https = require('https');
      const response = await new Promise((resolve, reject) => {
        const req = https.request('https://api.search.brave.com/res/v1/web/search?q=test&count=1', {
          method: 'GET',
          headers: {
            'Accept': 'application/json',
            'X-Subscription-Token': apiKey
          }
        }, (res) => {
          let data = '';
          res.on('data', chunk => data += chunk);
          res.on('end', () => resolve({ status: res.statusCode, data }));
        });
        req.on('error', reject);
        req.setTimeout(10000, () => reject(new Error('Timeout')));
        req.end();
      });
      
      if (response.status === 200) {
        return { valid: true, message: 'Connected to Brave Search' };
      } else if (response.status === 401 || response.status === 403) {
        return { valid: false, message: 'Invalid API key' };
      } else {
        return { valid: false, message: `HTTP ${response.status}` };
      }
    } catch (err) {
      return { valid: false, message: err.message };
    }
  },
  
  'google-workspace': async (fields) => {
    const oauthClientJson = fields.oauthClientJson?.value;
    if (!oauthClientJson) {
      return { valid: false, message: 'OAuth Client JSON path required' };
    }
    
    const fs = require('fs');
    if (!fs.existsSync(oauthClientJson)) {
      return { valid: false, message: `OAuth JSON file not found: ${oauthClientJson}` };
    }
    
    return { valid: true, message: 'Google Workspace OAuth configured' };
  },
  
  nanoBanana: async (fields) => {
    const apiKey = fields.apiKey?.value;
    if (!apiKey) return { valid: false, message: 'API Key required' };
    
    // Nano Banana uses Gemini API internally
    return { valid: null, message: 'Nano Banana validation not implemented - uses Gemini internally' };
  },
  
  whisper: async (fields) => {
    const apiKey = fields.apiKey?.value;
    if (!apiKey) return { valid: false, message: 'API Key required' };
    
    // Same as OpenAI validation
    try {
      const https = require('https');
      const response = await new Promise((resolve, reject) => {
        const req = https.request('https://api.openai.com/v1/models', {
          method: 'GET',
          headers: { 'Authorization': `Bearer ${apiKey}` }
        }, (res) => {
          let data = '';
          res.on('data', chunk => data += chunk);
          res.on('end', () => resolve({ status: res.statusCode }));
        });
        req.on('error', reject);
        req.setTimeout(10000, () => reject(new Error('Timeout')));
        req.end();
      });
      
      if (response.status === 200) {
        return { valid: true, message: 'Connected to OpenAI (Whisper ready)' };
      } else if (response.status === 401) {
        return { valid: false, message: 'Invalid API key (401)' };
      } else {
        return { valid: false, message: `HTTP ${response.status}` };
      }
    } catch (err) {
      return { valid: false, message: err.message };
    }
  },
  
  vapi: async (fields) => {
    const apiKey = fields.apiKey?.value;
    if (!apiKey) return { valid: false, message: 'API Key required' };
    
    try {
      const https = require('https');
      const response = await new Promise((resolve, reject) => {
        const req = https.request('https://api.vapi.ai/assistant', {
          method: 'GET',
          headers: { 'Authorization': `Bearer ${apiKey}` }
        }, (res) => {
          let data = '';
          res.on('data', chunk => data += chunk);
          res.on('end', () => resolve({ status: res.statusCode }));
        });
        req.on('error', reject);
        req.setTimeout(10000, () => reject(new Error('Timeout')));
        req.end();
      });
      
      if (response.status === 200) {
        return { valid: true, message: 'Connected to VAPI' };
      } else if (response.status === 401) {
        return { valid: false, message: 'Invalid API key (401)' };
      } else {
        return { valid: false, message: `HTTP ${response.status}` };
      }
    } catch (err) {
      return { valid: false, message: err.message };
    }
  },
  
  pinecone: async (fields) => {
    const apiKey = fields.apiKey?.value;
    const host = fields.host?.value || 'app.pinecone.io';
    
    if (!apiKey) return { valid: false, message: 'API Key required' };
    
    try {
      const https = require('https');
      const response = await new Promise((resolve, reject) => {
        const req = https.request(`https://${host}/actions/whoami`, {
          method: 'GET',
          headers: { 'Api-Key': apiKey }
        }, (res) => {
          let data = '';
          res.on('data', chunk => data += chunk);
          res.on('end', () => resolve({ status: res.statusCode, data }));
        });
        req.on('error', reject);
        req.setTimeout(10000, () => reject(new Error('Timeout')));
        req.end();
      });
      
      if (response.status === 200) {
        return { valid: true, message: 'Connected to Pinecone' };
      } else if (response.status === 401) {
        return { valid: false, message: 'Invalid API key (401)' };
      } else if (response.status === 404) {
        // Try alternative endpoint
        return { valid: null, message: 'Pinecone host reachable - validation limited' };
      } else {
        return { valid: false, message: `HTTP ${response.status}` };
      }
    } catch (err) {
      return { valid: false, message: err.message };
    }
  },
  
  stripe: async (fields) => {
    const secretKey = fields.secretKey?.value;
    if (!secretKey) return { valid: false, message: 'Secret Key required' };
    
    // Validate key format
    if (!secretKey.startsWith('sk_')) {
      return { valid: false, message: 'Invalid key format. Should start with sk_live_ or sk_test_' };
    }
    
    try {
      const https = require('https');
      const response = await new Promise((resolve, reject) => {
        const req = https.request('https://api.stripe.com/v1/account', {
          method: 'GET',
          headers: {
            'Authorization': `Bearer ${secretKey}`
          }
        }, (res) => {
          let data = '';
          res.on('data', chunk => data += chunk);
          res.on('end', () => resolve({ status: res.statusCode, data }));
        });
        req.on('error', reject);
        req.setTimeout(10000, () => reject(new Error('Timeout')));
        req.end();
      });
      
      if (response.status === 200) {
        const json = JSON.parse(response.data);
        const accountName = json.settings?.dashboard?.display_name || json.id;
        const mode = secretKey.includes('_live_') ? 'live' : 'test';
        return { valid: true, message: `Connected: ${accountName} (${mode} mode)` };
      } else if (response.status === 401) {
        return { valid: false, message: 'Invalid API key (401)' };
      } else {
        return { valid: false, message: `Stripe API error: ${response.status}` };
      }
    } catch (err) {
      return { valid: false, message: err.message };
    }
  },

  github: async (fields) => {
    const token = fields.token?.value;
    
    if (!token) return { valid: false, message: 'Personal Access Token required' };
    
    // Validate token format
    if (!token.startsWith('ghp_') && !token.startsWith('github_pat_')) {
      return { valid: false, message: 'Invalid token format. Should start with ghp_ or github_pat_' };
    }
    
    try {
      const response = await fetch('https://api.github.com/user', {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Accept': 'application/vnd.github+json',
          'X-GitHub-Api-Version': '2022-11-28'
        }
      });
      
      if (response.ok) {
        const data = await response.json();
        return { valid: true, message: `Connected as @${data.login}` };
      } else if (response.status === 401) {
        return { valid: false, message: 'Invalid or expired token (401)' };
      } else if (response.status === 403) {
        return { valid: false, message: 'Token lacks required permissions (403)' };
      } else {
        return { valid: false, message: `GitHub API error: ${response.status}` };
      }
    } catch (err) {
      return { valid: false, message: `Connection failed: ${err.message}` };
    }
  }
};

// Merge package validators (loaded from packages/ directory)
const packageValidators = getPackageValidators();
for (const [id, validator] of Object.entries(packageValidators)) {
  VALIDATORS[id] = validator;
}

app.post('/api/services/:id/validate', requireAuth, async (req, res) => {
  const { id } = req.params;
  
  // First check if this is a credential ID (new system)
  const credential = getCredential(id);
  if (credential) {
    const packageId = credential._package;
    
    // Use live validator if available for the package type
    if (VALIDATORS[packageId]) {
      const result = await VALIDATORS[packageId](credential.fields || {});
      return res.json(result);
    }
    
    // Fall back to schema-based validation
    const schema = SERVICE_SCHEMAS[packageId];
    if (!schema || !schema.validation) {
      return res.json({ valid: null, message: 'No validation configured for this service type' });
    }
    
    return res.json({ 
      valid: null, 
      message: `Would test: ${schema.validation.endpoint}`,
      note: 'Live validation coming soon'
    });
  }
  
  // Legacy: check for service ID
  const service = getService(id);
  if (VALIDATORS[id]) {
    const result = await VALIDATORS[id](service?.fields || {});
    return res.json(result);
  }
  
  res.json({ valid: null, message: 'Service not found' });
});

app.post('/api/regenerate', requireAuth, (req, res) => {
  const { generateToolsMd } = require('./lib/generator');
  const path = generateToolsMd();
  res.json({ success: true, path });
});

app.get('/api/toolsmd/backups', requireAuth, (req, res) => {
  try {
    const backupDir = path.join(process.env.HOME || '/home/alex', '.openclaw/workspace/.tools-md-backups');
    const backups = [];
    for (let i = 1; i <= 4; i++) {
      const backupPath = path.join(backupDir, `TOOLS.md.${i}`);
      if (fs.existsSync(backupPath)) {
        const stats = fs.statSync(backupPath);
        backups.push({
          version: i,
          date: stats.mtime.toISOString(),
          size: stats.size
        });
      }
    }
    res.json({ backups });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/toolsmd/restore/:version', requireAuth, (req, res) => {
  try {
    const version = parseInt(req.params.version);
    if (version < 1 || version > 4) {
      return res.status(400).json({ error: 'Invalid backup version (1-4)' });
    }
    
    const backupDir = path.join(process.env.HOME || '/home/alex', '.openclaw/workspace/.tools-md-backups');
    const backupPath = path.join(backupDir, `TOOLS.md.${version}`);
    const toolsMdPath = path.join(process.env.HOME || '/home/alex', '.openclaw/workspace/TOOLS.md');
    
    if (!fs.existsSync(backupPath)) {
      return res.status(404).json({ error: 'Backup not found' });
    }
    
    // Backup current before restoring
    const { backupToolsMd } = require('./lib/generator');
    backupToolsMd();
    
    // Restore
    fs.copyFileSync(backupPath, toolsMdPath);
    res.json({ success: true, message: `Restored from backup ${version}` });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/toolsmd', requireAuth, (req, res) => {
  try {
    const fs = require('fs');
    const path = require('path');
    const toolsMdPath = path.join(process.env.HOME || '/home/alex', '.openclaw/workspace/TOOLS.md');
    
    if (fs.existsSync(toolsMdPath)) {
      const content = fs.readFileSync(toolsMdPath, 'utf8');
      res.json({ content });
    } else {
      res.json({ content: '# TOOLS.md not found\n\nClick "Regenerate TOOLS.md" to create it.' });
    }
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Health check - validate all credentials
app.get('/api/health', requireAuth, async (req, res) => {
  try {
    const credentials = listCredentials();
    const results = [];
    let passed = 0;
    let failed = 0;
    let unknown = 0;
    
    for (const [id, cred] of Object.entries(credentials)) {
      const validator = VALIDATORS[cred._package];
      let status = 'unknown';
      let message = 'No validation configured';
      
      if (validator) {
        try {
          const result = await validator(cred.fields || {});
          if (result.valid === true) {
            status = 'pass';
            message = result.message;
            passed++;
          } else if (result.valid === false) {
            status = 'fail';
            message = result.message;
            failed++;
          } else {
            status = 'unknown';
            message = result.message || 'Validation returned null';
            unknown++;
          }
        } catch (err) {
          status = 'fail';
          message = err.message;
          failed++;
        }
      } else {
        unknown++;
      }
      
      results.push({
        id,
        name: cred._name,
        packageId: cred._package,
        status,
        message
      });
    }
    
    const total = results.length;
    const allSystemsGo = failed === 0;
    
    res.json({
      summary: {
        total,
        passed,
        failed,
        unknown,
        allSystemsGo,
        status: allSystemsGo ? 'ALL_SYSTEMS_GO' : 'ISSUES_DETECTED'
      },
      results
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/registry/path', requireAuth, (req, res) => {
  res.json({ path: REGISTRY_PATH });
});

// ============================================
// CREDENTIAL API (n8n-style multiple instances)
// ============================================

// List all credentials
app.get('/api/credentials', requireAuth, (req, res) => {
  const credentials = listCredentials();
  const result = {};
  
  for (const [id, cred] of Object.entries(credentials)) {
    const schema = SERVICE_SCHEMAS[cred._package];
    result[id] = {
      id,
      name: cred._name,
      packageId: cred._package,
      packageName: schema?.name || cred._package,
      category: schema?.category || 'custom',
      icon: schema?.icon || '⚙️',
      fields: cred.fields,
      createdAt: cred.createdAt,
      updatedAt: cred.updatedAt
    };
  }
  
  res.json({ credentials: result });
});

// List credentials by package type
app.get('/api/credentials/package/:packageId', requireAuth, (req, res) => {
  const { packageId } = req.params;
  const credentials = listCredentialsByPackage(packageId);
  res.json({ credentials });
});

// Create new credential
app.post('/api/credentials', requireAuth, (req, res) => {
  try {
    const { packageId, name, fields } = req.body;
    
    if (!packageId || !name) {
      return res.status(400).json({ error: 'packageId and name required' });
    }
    
    const schema = SERVICE_SCHEMAS[packageId];
    if (!schema) {
      return res.status(404).json({ error: 'Package not found' });
    }
    
    // Generate unique ID
    const credentialId = `${packageId}-${Date.now()}`;
    
    const credential = createCredential(credentialId, {
      packageId,
      name,
      fields: fields || {}
    });
    
    res.json({ 
      success: true, 
      credential: {
        id: credentialId,
        name: credential._name,
        packageId: credential._package
      }
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get single credential
app.get('/api/credentials/:id', requireAuth, (req, res) => {
  const credential = getCredential(req.params.id);
  if (!credential) {
    return res.status(404).json({ error: 'Credential not found' });
  }
  
  const schema = SERVICE_SCHEMAS[credential._package];
  res.json({
    id: req.params.id,
    name: credential._name,
    packageId: credential._package,
    schema,
    fields: credential.fields
  });
});

// Update credential (fields or name)
app.put('/api/credentials/:id', requireAuth, (req, res) => {
  try {
    const { name, fields } = req.body;
    const credential = updateCredential(req.params.id, { name, fields });
    res.json({ success: true, credential });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Rename credential
app.put('/api/credentials/:id/rename', requireAuth, (req, res) => {
  try {
    const { name } = req.body;
    if (!name) {
      return res.status(400).json({ error: 'name required' });
    }
    
    const credential = updateCredential(req.params.id, { name });
    res.json({ success: true, credential });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Delete credential
app.delete('/api/credentials/:id', requireAuth, (req, res) => {
  const success = deleteCredential(req.params.id);
  if (success) {
    res.json({ success: true, message: 'Credential deleted' });
  } else {
    res.status(404).json({ error: 'Credential not found' });
  }
});

// Validate credential
app.post('/api/credentials/:id/validate', requireAuth, async (req, res) => {
  const credential = getCredential(req.params.id);
  if (!credential) {
    return res.status(404).json({ error: 'Credential not found' });
  }
  
  const validator = VALIDATORS[credential._package];
  if (!validator) {
    return res.json({ valid: null, message: 'No validation configured' });
  }
  
  try {
    const result = await validator(credential.fields);
    res.json(result);
  } catch (err) {
    res.json({ valid: false, message: err.message });
  }
});

// Protected pages
app.get('/', requireAuthPage, (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.get('/service/:id', requireAuthPage, (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Static files (after protected routes, only for non-protected assets)
// Explicitly serve login.html without auth
app.get('/login.html', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'login.html'));
});

// Start server
function startServer() {
  const [host, portStr] = CONFIG.bind.split(':');
  const port = parseInt(portStr) || 8080;
  
  const serverCallback = () => {
    console.log(`
╔══════════════════════════════════════════════════════════╗
║  OpenClaw Tools Config Server v0.1.0                     ║
╠══════════════════════════════════════════════════════════╣
║  URL:      http${CONFIG.https ? 's' : ''}://${host}:${port}                    ║
║  Password: ${CONFIG.password.padEnd(42)} ║
${CONFIG.temp ? `║  Temp mode: Server stops in ${CONFIG.temp} minutes${' '.repeat(17 - CONFIG.temp.toString().length)} ║\n` : ''}╚══════════════════════════════════════════════════════════╝

Registry: ${REGISTRY_PATH}
    `);
    
    if (CONFIG.temp) {
      setTimeout(() => {
        console.log('\n⏰ Temp time expired. Shutting down...');
        process.exit(0);
      }, CONFIG.temp * 60 * 1000);
    }
  };
  
  if (CONFIG.https) {
    // Generate self-signed cert
    const certDir = path.join(__dirname, '.certs');
    if (!fs.existsSync(certDir)) fs.mkdirSync(certDir, { recursive: true });
    
    const keyPath = path.join(certDir, 'key.pem');
    const certPath = path.join(certDir, 'cert.pem');
    
    if (!fs.existsSync(keyPath) || !fs.existsSync(certPath)) {
      console.log('Generating self-signed certificate (valid for 1 year)...');
      const { execSync } = require('child_process');
      execSync(`openssl req -x509 -newkey rsa:2048 -keyout ${keyPath} -out ${certPath} -days 365 -nodes -subj "/CN=localhost" 2>/dev/null`);
    }
    
    https.createServer({
      key: fs.readFileSync(keyPath),
      cert: fs.readFileSync(certPath)
    }, app).listen(port, host, serverCallback);
  } else {
    app.listen(port, host, serverCallback);
  }
}

startServer();