#!/bin/bash
cd /home/alex/.openclaw/workspace/tools-server
pkill -f "server.js --bind" 2>/dev/null
sleep 1
rm -rf .certs
export PASSWORD="${1:-mel2026}"
export BIND="${2:-100.84.57.51:8443}"
node server.js --bind "$BIND" --https --password "$PASSWORD" &
sleep 3
echo "Server started on https://$BIND"
openssl x509 -in .certs/cert.pem -noout -dates 2>/dev/null | grep notAfter