// Service schemas - defines the form structure for each integration

const AGENT_SCHEMA = {
  id: 'mel',
  name: 'Mel (Agent Behavior)',
  category: 'agent',
  icon: '✨',
  description: 'Agent behavior and rate limit settings',
  fields: [
    { 
      key: 'rateLimitNotify', 
      label: 'Notify on rate limits (429)', 
      type: 'select', 
      required: true, 
      options: ['always', 'after-3-retries', 'never'],
      default: 'always',
      help: 'When to inform user about rate limit errors'
    },
    { 
      key: 'rateLimitPauseSeconds', 
      label: 'Pause duration (seconds)', 
      type: 'number', 
      required: false, 
      placeholder: '30',
      default: '30',
      help: 'How long to pause when hitting 429 before retrying'
    },
    { 
      key: 'rateLimitMaxRetries', 
      label: 'Max retries', 
      type: 'number', 
      required: false, 
      placeholder: '3',
      default: '3',
      help: 'Maximum retry attempts with exponential backoff'
    },
    {
      key: 'rateLimitBackoffMultiplier',
      label: 'Backoff multiplier',
      type: 'number',
      required: false,
      placeholder: '2',
      default: '2',
      help: 'Multiply wait time by this factor on each retry (1.5 = conservative, 2 = standard, 3 = aggressive)'
    }
  ]
};

const SERVICE_SCHEMAS = {
  notion: {
    id: 'notion',
    name: 'Notion',
    category: 'productivity',
    icon: '📋',
    description: 'Note-taking and databases',
    fields: [
      { key: 'apiKey', label: 'API Key', type: 'password', required: true, sensitive: true, help: 'From notion.so/my-integrations' },
      { key: 'dbHome', label: 'Home DB ID', type: 'text', required: false },
      { key: 'dbTodos', label: 'Todos DB ID', type: 'text', required: false },
      { key: 'dbSupplements', label: 'Supplements DB ID', type: 'text', required: false }
    ],
    validation: {
      endpoint: 'https://api.notion.com/v1/users/me',
      headers: { 'Notion-Version': '2022-06-28' }
    }
  },

  todoist: {
    id: 'todoist',
    name: 'Todoist',
    category: 'productivity',
    icon: '✅',
    description: 'Task management',
    fields: [
      { key: 'apiToken', label: 'API Token', type: 'password', required: true, sensitive: true, help: 'From todoist.com/app/settings/integrations' }
    ],
    validation: {
      endpoint: 'https://api.todoist.com/api/v1/projects',
      source: '1password',
      item: 'Todoist API',
      field: 'credential'
    }
  },

  n8n: {
    id: 'n8n',
    name: 'n8n',
    category: 'automation',
    icon: '⚙️',
    description: 'Workflow automation',
    fields: [
      { key: 'apiKey', label: 'API Key', type: 'password', required: true, sensitive: true, source: '1password', item: 'n8n API', field: 'credential' },
      { key: 'hostUrl', label: 'Host URL', type: 'url', required: true, placeholder: 'https://n8n.example.com', source: '1password', item: 'n8n API', field: 'hostname' },
      { key: 'webhook17track', label: '17TRACK Webhook', type: 'url', required: false, placeholder: 'https://n8n.../webhook/17track-to-mel' }
    ]
  },

  oura: {
    id: 'oura',
    name: 'Oura',
    category: 'health',
    icon: '💍',
    description: 'Sleep and health tracking',
    fields: [
      { key: 'clientId', label: 'Client ID', type: 'text', required: true, source: '1password', item: 'Oura API' },
      { key: 'clientSecret', label: 'Client Secret', type: 'password', required: true, sensitive: true, source: '1password', item: 'Oura API', field: 'credential' }
    ]
  },

  '17track': {
    id: '17track',
    name: '17TRACK',
    category: 'logistics',
    icon: '📦',
    description: 'Package tracking',
    fields: [
      { key: 'apiKey', label: 'API Key', type: 'password', required: true, sensitive: true, source: '1password', item: '17TRACK API', field: 'credential' }
    ]
  },

  amadeus: {
    id: 'amadeus',
    name: 'Amadeus',
    category: 'travel',
    icon: '✈️',
    description: 'Flight search API',
    fields: [
      { key: 'clientId', label: 'Client ID', type: 'text', required: true, source: '1password', item: 'Amadeus API', field: 'credential' },
      { key: 'clientSecret', label: 'Client Secret', type: 'password', required: true, sensitive: true, source: '1password', item: 'Amadeus API', field: 'Private API key' },
      { key: 'environment', label: 'Environment', type: 'select', required: true, options: ['production', 'test'], default: 'production' }
    ]
  },

  telegram: {
    id: 'telegram',
    name: 'Telegram Bot',
    category: 'messaging',
    icon: '💬',
    description: 'Bot integration',
    fields: [
      { key: 'botToken', label: 'Bot Token', type: 'password', required: true, sensitive: true, help: 'From @BotFather' },
      { key: 'chatId', label: 'Chat ID', type: 'text', required: false, placeholder: '58748195' }
    ]
  },

  weather: {
    id: 'weather',
    name: 'Weather',
    category: 'lifestyle',
    icon: '🌤️',
    description: 'Weather data (Open-Meteo, no key needed)',
    fields: [
      { key: 'provider', label: 'Provider', type: 'select', required: true, options: ['open-meteo', 'openweathermap'], default: 'open-meteo' },
      { key: 'apiKey', label: 'API Key (if OWM)', type: 'password', required: false, sensitive: true, help: 'Only needed for OpenWeatherMap' }
    ]
  },

  elevenlabs: {
    id: 'elevenlabs',
    name: 'ElevenLabs',
    category: 'voice',
    icon: '🗣️',
    description: 'Text-to-speech',
    fields: [
      { key: 'apiKey', label: 'API Key', type: 'password', required: true, sensitive: true, source: 'openclaw-skill', skill: 'sag' },
      { key: 'defaultVoiceId', label: 'Default Voice ID', type: 'text', required: false, placeholder: 'cgSgspJ2msm6clMCkdW9' }
    ]
  },

  perplexity: {
    id: 'perplexity',
    name: 'Perplexity',
    category: 'ai',
    icon: '🔮',
    description: 'AI search',
    fields: [
      { key: 'apiKey', label: 'API Key', type: 'password', required: true, sensitive: true }
    ]
  },

  duffel: {
    id: 'duffel',
    name: 'Duffel',
    category: 'travel',
    icon: '🎫',
    description: 'Flight search (sandbox)',
    fields: [
      { key: 'apiKey', label: 'API Key', type: 'password', required: true, sensitive: true }
    ]
  },

  aviationstack: {
    id: 'aviationstack',
    name: 'Aviationstack',
    category: 'travel',
    icon: '🛫',
    description: 'Flight status API',
    fields: [
      { key: 'apiKey', label: 'API Key', type: 'password', required: true, sensitive: true }
    ]
  },

  'google-workspace': {
    id: 'google-workspace',
    name: 'Google Workspace',
    category: 'productivity',
    icon: '🔷',
    description: 'Gmail, Calendar, Drive',
    fields: [
      { key: 'oauthClientJson', label: 'OAuth Client JSON Path', type: 'text', required: true, placeholder: '~/.config/gog/client_secret_...json' },
      { key: 'keyringPassword', label: 'Keyring Password Source', type: 'select', required: true, options: ['1password', 'file', 'env'], default: '1password' }
    ]
  },

  goplaces: {
    id: 'goplaces',
    name: 'Google Places',
    category: 'location',
    icon: '📍',
    description: 'Places API (New)',
    fields: [
      { key: 'apiKey', label: 'API Key', type: 'password', required: true, sensitive: true }
    ]
  },

  newsapi: {
    id: 'newsapi',
    name: 'NewsAPI',
    category: 'news',
    icon: '📰',
    description: 'News headlines',
    fields: [
      { key: 'apiKey', label: 'API Key', type: 'password', required: true, sensitive: true }
    ]
  },

  openexchangerates: {
    id: 'openexchangerates',
    name: 'Open Exchange Rates',
    category: 'finance',
    icon: '💱',
    description: 'Currency conversion',
    fields: [
      { key: 'apiKey', label: 'API Key', type: 'password', required: true, sensitive: true }
    ]
  },

  openai: {
    id: 'openai',
    name: 'OpenAI',
    category: 'ai',
    icon: '🤖',
    description: 'GPT models',
    fields: [
      { key: 'apiKey', label: 'API Key', type: 'password', required: true, sensitive: true },
      { key: 'orgId', label: 'Organization ID', type: 'text', required: false }
    ]
  },

  anthropic: {
    id: 'anthropic',
    name: 'Anthropic',
    category: 'ai',
    icon: '🧠',
    description: 'Claude models',
    fields: [
      { key: 'apiKey', label: 'API Key', type: 'password', required: true, sensitive: true }
    ]
  },

  moonshot: {
    id: 'moonshot',
    name: 'Moonshot',
    category: 'ai',
    icon: '🌙',
    description: 'Kimi models',
    fields: [
      { key: 'apiKey', label: 'API Key', type: 'password', required: true, sensitive: true }
    ]
  },

  nanoBanana: {
    id: 'nanoBanana',
    name: 'Nano Banana Pro',
    category: 'image',
    icon: '🖼️',
    description: 'Image generation',
    fields: [
      { key: 'apiKey', label: 'API Key', type: 'password', required: true, sensitive: true }
    ]
  },

  whisper: {
    id: 'whisper',
    name: 'OpenAI Whisper',
    category: 'audio',
    icon: '🎙️',
    description: 'Speech-to-text',
    fields: [
      { key: 'apiKey', label: 'API Key', type: 'password', required: true, sensitive: true }
    ]
  },

  vapi: {
    id: 'vapi',
    name: 'VAPI',
    category: 'voice',
    icon: '📞',
    description: 'Voice AI platform',
    fields: [
      { key: 'apiKey', label: 'API Key', type: 'password', required: true, sensitive: true },
      { key: 'assistantId', label: 'Assistant ID', type: 'text', required: false },
      { key: 'phoneNumberId', label: 'Phone Number ID', type: 'text', required: false }
    ]
  },

  hubspot: {
    id: 'hubspot',
    name: 'HubSpot',
    category: 'crm',
    icon: '🟠',
    description: 'CRM integration',
    fields: [
      { key: 'accessToken', label: 'Private Access Token', type: 'password', required: true, sensitive: true }
    ]
  },

  pinecone: {
    id: 'pinecone',
    name: 'Pinecone',
    category: 'vector-db',
    icon: '🌲',
    description: 'Vector database',
    fields: [
      { key: 'apiKey', label: 'API Key', type: 'password', required: true, sensitive: true },
      { key: 'host', label: 'Host', type: 'text', required: true, placeholder: 'app.pinecone.io', default: 'app.pinecone.io' },
      { key: 'environment', label: 'Environment', type: 'text', required: false, placeholder: 'us-east1-gcp' }
    ]
  },

  brave: {
    id: 'brave',
    name: 'Brave Search',
    category: 'search',
    icon: '🦁',
    description: 'Web search API',
    fields: [
      { key: 'apiKey', label: 'API Key', type: 'password', required: true, sensitive: true }
    ]
  }
};

module.exports = { SERVICE_SCHEMAS, AGENT_SCHEMA };