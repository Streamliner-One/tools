#!/bin/bash
cd /home/alex/.openclaw/workspace/tools-server
pkill -f "server.js --bind" 2>/dev/null
sleep 2
export PASSWORD="${1:-mel2026}"
export BIND="${2:-100.84.57.51:8443}"
node server.js --bind "$BIND" --https --password "$PASSWORD" &
sleep 2
echo "Server PID: $!"
ls .certs/ 2>/dev/null