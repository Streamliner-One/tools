# OpenClaw Tools Config Server - API Documentation

## Overview

REST API for managing tool credentials (API keys, tokens, webhooks) with n8n-style multiple instances per connector type.

**Base URL:** `https://your-server:8443`

**Authentication:** Password-protected session cookie

---

## Authentication

### POST /api/login
Login to obtain session cookie.

**Request:**
```json
{
  "password": "your-password"
}
```

**Response:**
```json
{
  "success": true
}
```

Sets `tools_session` cookie for subsequent requests.

---

## Credentials (Main API)

### GET /api/credentials
List all configured credentials.

**Response:**
```json
{
  "credentials": {
    "stripe-123456": {
      "id": "stripe-123456",
      "name": "Stripe - Production",
      "packageId": "stripe",
      "packageName": "Stripe",
      "category": "payment",
      "icon": "💳",
      "fields": {
        "secretKey": { "value": "sk_live_..." },
        "mode": { "value": "live" }
      },
      "createdAt": "2026-03-01T10:00:00Z",
      "updatedAt": "2026-03-01T10:00:00Z"
    }
  }
}
```

### GET /api/credentials/:id
Get specific credential with all field values.

**Response:**
```json
{
  "id": "stripe-123456",
  "name": "Stripe - Production",
  "packageId": "stripe",
  "schema": { /* full package schema */ },
  "fields": {
    "secretKey": { "value": "sk_live_..." },
    "mode": { "value": "live" }
  }
}
```

### POST /api/credentials
Create new credential instance.

**Request:**
```json
{
  "packageId": "stripe",
  "name": "Stripe - Production",
  "fields": {
    "secretKey": { "value": "sk_live_..." },
    "mode": { "value": "live" }
  }
}
```

**Response:**
```json
{
  "success": true,
  "credential": {
    "id": "stripe-1234567890",
    "name": "Stripe - Production",
    "packageId": "stripe"
  }
}
```

### PUT /api/credentials/:id
Update credential (name and/or fields).

**Request:**
```json
{
  "name": "Stripe - New Name",
  "fields": {
    "secretKey": { "value": "sk_live_new..." }
  }
}
```

### PUT /api/credentials/:id/rename
Rename credential only.

**Request:**
```json
{
  "name": "Stripe - Updated Name"
}
```

### DELETE /api/credentials/:id
Delete credential instance.

**Response:**
```json
{
  "success": true,
  "message": "Credential deleted"
}
```

### POST /api/credentials/:id/validate
Test connection for specific credential.

**Response (success):**
```json
{
  "valid": true,
  "message": "Connected: Account Name (live mode)"
}
```

**Response (failure):**
```json
{
  "valid": false,
  "message": "Invalid API key (401)"
}
```

---

## Health Check

### GET /api/health
System-wide validation of all credentials.

**Response:**
```json
{
  "summary": {
    "total": 26,
    "passed": 23,
    "failed": 0,
    "unknown": 3,
    "allSystemsGo": true,
    "status": "ALL_SYSTEMS_GO"
  },
  "results": [
    {
      "id": "stripe-123456",
      "name": "Stripe - Production",
      "packageId": "stripe",
      "status": "pass",
      "message": "Connected: Streamliner One LLC (live mode)"
    },
    {
      "id": "notion-789",
      "name": "Notion - Work",
      "packageId": "notion",
      "status": "pass",
      "message": "Connected as SuperCEO"
    }
  ]
}
```

**Status values:**
- `pass` - Connection successful
- `fail` - Connection failed (check message)
- `unknown` - No validator configured (normal for OAuth/internal tools)

---

## Package Schemas

### GET /api/services
List all available package types with schemas.

**Response:**
```json
{
  "services": [
    {
      "id": "stripe",
      "name": "Stripe",
      "category": "payment",
      "icon": "💳",
      "description": "Payment processing",
      "fields": [
        {
          "key": "secretKey",
          "label": "Secret Key",
          "type": "password",
          "required": true,
          "sensitive": true,
          "placeholder": "sk_live_..."
        },
        {
          "key": "mode",
          "label": "Mode",
          "type": "select",
          "required": true,
          "options": ["test", "live"],
          "default": "test"
        }
      ]
    }
  ]
}
```

---

## Utility Endpoints

### GET /api/toolsmd
Get generated TOOLS.md content.

### POST /api/regenerate
Regenerate TOOLS.md from current credentials.

### GET /api/toolsmd/backups
List available TOOLS.md backups.

### POST /api/toolsmd/restore/:version
Restore from backup (version 1-4).

### GET /api/registry/path
Get registry file path.

---

## Agent Usage Examples

### Discover Available Tools
```javascript
const tools = await fetch('/api/credentials').then(r => r.json());
// "I see you have Stripe, Notion, OpenAI configured..."
```

### Get API Key When Needed
```javascript
const stripe = await fetch('/api/credentials/stripe-123').then(r => r.json());
const apiKey = stripe.fields.secretKey.value;
// Use with Stripe SDK
```

### Validate Before Using
```javascript
const test = await fetch('/api/credentials/stripe-123/validate', {
  method: 'POST'
}).then(r => r.json());

if (test.valid) {
  // Proceed with API call
} else {
  // Alert user: "Stripe connection failed: Invalid API key"
}
```

### System Health Check
```javascript
const health = await fetch('/api/health').then(r => r.json());

if (health.summary.allSystemsGo) {
  return `✅ All systems go! ${health.summary.passed}/${health.summary.total} integrations passing.`;
} else {
  const failed = health.results.filter(r => r.status === 'fail');
  return `⚠️ Issues detected:\n${failed.map(f => `- ${f.name}: ${f.message}`).join('\n')}`;
}
```

---

## Error Responses

**401 Unauthorized:**
```json
{ "error": "Unauthorized" }
```

**404 Not Found:**
```json
{ "error": "Credential not found" }
```

**400 Bad Request:**
```json
{ "error": "packageId and name required" }
```

**500 Server Error:**
```json
{ "error": "Error message" }
```

---

## Field Types

| Type | UI | Example |
|------|-----|---------|
| `text` | Text input | API URLs, IDs |
| `password` | Masked input | API keys, tokens |
| `url` | URL validation | Webhook endpoints |
| `select` | Dropdown | Mode: test/live |
| `number` | Number input | Port numbers |

---

## Security Notes

- All endpoints require authentication (except `/login`)
- HTTPS only (self-signed cert acceptable)
- Session cookie: `tools_session`
- Password: bcrypt hashed
- Sensitive fields masked in UI
- Keys never logged