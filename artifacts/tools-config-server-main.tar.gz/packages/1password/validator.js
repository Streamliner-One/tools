/**
 * 1Password Validator - Uses Service Account Token
 */

const { exec } = require('child_process');
const util = require('util');
const execPromise = util.promisify(exec);

async function validate(fields) {
  const token = fields.serviceAccountToken?.value;
  
  if (!token) {
    return {
      valid: false,
      message: 'Service Account Token required'
    };
  }
  
  // Validate token format
  if (!token.startsWith('ops_')) {
    return {
      valid: false,
      message: 'Invalid token format. Should start with ops_'
    };
  }
  
  try {
    // Clear any conflicting config
    const { execSync } = require('child_process');
    try {
      execSync('rm -rf ~/.config/op', { stdio: 'ignore' });
    } catch {}
    
    // Test with service account token
    const { stdout } = await execPromise('op vault list --format json', {
      env: {
        ...process.env,
        OP_SERVICE_ACCOUNT_TOKEN: token
      }
    });
    
    const vaults = JSON.parse(stdout);
    const vaultNames = vaults.map(v => v.name).join(', ');
    
    return {
      valid: true,
      message: `✅ Connected! Access to ${vaults.length} vaults: ${vaultNames}`
    };
    
  } catch (err) {
    return {
      valid: false,
      message: 'Connection failed: ' + (err.stderr || err.message)
    };
  }
}

module.exports = { validate };