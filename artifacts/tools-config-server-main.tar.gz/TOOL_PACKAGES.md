# Tool Packages — Extensible Integration System

Self-contained, versioned tool definitions that can be uploaded to the Tools Config Server without code changes.

## Package Format

```
tool-packages/
├── supabase/
│   ├── package.json          # Manifest
│   ├── schema.json           # Field definitions
│   ├── validator.js          # Optional: custom validation logic
│   ├── icon.svg              # Icon (or use emoji)
│   └── README.md             # Documentation
```

## 1. Package Manifest (package.json)

```json
{
  "id": "supabase",
  "name": "Supabase",
  "version": "1.0.0",
  "description": "PostgreSQL database with realtime subscriptions",
  "icon": "🟢",
  "category": "database",
  "author": "Streamliner One",
  "minServerVersion": "0.2.0",
  
  "schema": "schema.json",
  "validator": "validator.js",
  
  "fields": {
    "url": {
      "label": "Project URL",
      "type": "url",
      "required": true,
      "placeholder": "https://xxxxx.supabase.co"
    },
    "anonKey": {
      "label": "Anon Public Key",
      "type": "password",
      "required": true,
      "sensitive": true
    },
    "serviceKey": {
      "label": "Service Role Key",
      "type": "password", 
      "required": false,
      "sensitive": true
    }
  }
}
```

## 2. Declarative Validation (No Code Required)

For simple HTTP-based validation, use declarative format:

```json
{
  "validation": {
    "type": "http",
    "endpoint": "{{url}}/rest/v1/",
    "method": "GET",
    "headers": {
      "apikey": "{{anonKey}}",
      "Authorization": "Bearer {{anonKey}}"
    },
    "expectedStatus": 200,
    "successMessage": "Connected to Supabase",
    "errorMessages": {
      "401": "Invalid API key",
      "404": "Project URL not found"
    }
  }
}
```

## 3. Dynamic Fields (Your Notion Use Case)

For tools with dynamic/custom fields (like multiple Notion databases):

```json
{
  "dynamicFields": {
    "enabled": true,
    "label": "Custom Databases",
    "description": "Add IDs for additional Notion databases",
    "fieldTemplate": {
      "key": "db{{index}}",
      "label": "Database {{index}} ID",
      "type": "text",
      "required": false
    },
    "maxFields": 10
  }
}
```

This renders as:
- "Database 1 ID" field
- "Database 2 ID" field  
- ... up to 10
- User can add/remove dynamically in UI

## 4. Advanced: Custom Validator (validator.js)

For complex validation, ship JavaScript:

```javascript
// validator.js - runs in sandboxed VM
module.exports = {
  async validate(fields) {
    const { url, anonKey } = fields;
    
    // Custom validation logic
    try {
      const response = await fetch(`${url}/rest/v1/`, {
        headers: {
          'apikey': anonKey,
          'Authorization': `Bearer ${anonKey}`
        }
      });
      
      if (response.status === 200) {
        const projects = await response.json();
        return {
          valid: true,
          message: `Connected. ${projects.length} tables accessible.`
        };
      }
      
      return { valid: false, message: `HTTP ${response.status}` };
    } catch (err) {
      return { valid: false, message: err.message };
    }
  }
};
```

## 5. Installation Methods

### Method A: Upload via Web UI
1. Zip the tool-package folder
2. Dashboard → "Install Tool Package" → Upload
3. Server validates, installs, shows new card

### Method B: CLI / Git
```bash
# Clone community packages
git clone https://github.com/streamliner/tool-packages.git

# Install specific tool
cd tool-packages/supabase
claw-tools install .

# Or direct from URL
claw-tools install https://clawhub.com/tools/supabase/v1.0.0.pkg
```

### Method C: Registry / Marketplace
```bash
# Browse available packages
claw-tools search database

# Install
claw-tools install supabase
```

## 6. Server-Side Integration

When a package is installed, the server:

```javascript
// 1. Load package.json
const pkg = JSON.parse(fs.readFileSync('package.json'));

// 2. Merge schema into SERVICE_SCHEMAS
SERVICE_SCHEMAS[pkg.id] = {
  id: pkg.id,
  name: pkg.name,
  category: pkg.category,
  icon: pkg.icon,
  description: pkg.description,
  fields: Object.entries(pkg.fields).map(([key, def]) => ({
    key,
    ...def
  })),
  dynamicFields: pkg.dynamicFields
};

// 3. Register validator
if (pkg.validation) {
  // Declarative validation
  VALIDATORS[pkg.id] = createDeclarativeValidator(pkg.validation);
} else if (fs.existsSync('validator.js')) {
  // Custom JS validation (sandboxed)
  VALIDATORS[pkg.id] = createSandboxedValidator('validator.js');
}

// 4. Persist to installed-packages.json
// 5. Regenerate TOOLS.md
```

## 7. Example: Complete Notion Package

```json
{
  "id": "notion-enhanced",
  "name": "Notion (Enhanced)",
  "version": "2.0.0",
  "description": "Notion with unlimited custom databases",
  "icon": "📋",
  "category": "productivity",
  
  "fields": {
    "apiKey": {
      "label": "Integration Token",
      "type": "password",
      "required": true,
      "sensitive": true,
      "help": "From notion.so/my-integrations"
    }
  },
  
  "dynamicFields": {
    "enabled": true,
    "label": "Additional Databases",
    "addButtonText": "+ Add Database",
    "fieldTemplate": {
      "prefix": "db",
      "label": "{{name}} Database ID",
      "type": "text",
      "placeholder": "Paste database ID or URL"
    },
    "naming": {
      "field": "dbName{{index}}",
      "value": "dbValue{{index}}"
    }
  },
  
  "validation": {
    "type": "http",
    "endpoint": "https://api.notion.com/v1/users/me",
    "headers": {
      "Authorization": "Bearer {{apiKey}}",
      "Notion-Version": "2022-06-28"
    },
    "expectedStatus": 200,
    "successMessage": "Connected as {{response.name}}"
  }
}
```

UI would show:
```
[API Key field]

Additional Databases:
[Name: Home] [ID: 1c443fe2...] [🗑️]
[Name: Todos] [ID: c2cb2ad8...] [🗑️]
[+ Add Database]
```

## 8. Security & Sandboxing

Custom validators run in a restricted VM:
- ✅ Network access to configured endpoints only
- ✅ No file system access outside package folder
- ✅ Timeout: 10 seconds max
- ✅ No dynamic code execution (eval, Function)
- ✅ Memory limits enforced

## 9. Distribution

### Private Packages
```bash
# For managed OpenClaw installations
tar czf custom-tool-v1.0.0.pkg tool-folder/
scp custom-tool-v1.0.0.pkg client-server:/tmp/
# Client installs via UI
```

### Public Registry
```bash
# Submit to ClawHub (future)
claw-tools publish .
# Reviewed, approved, available to all
```

## 10. Versioning & Updates

```json
{
  "id": "supabase",
  "version": "1.1.0",
  "changelog": "Added storage bucket configuration",
  "migration": {
    "from": "1.0.x",
    "script": "migrate.js"  // Optional: transform old config
  }
}
```

Server shows: "Update available: 1.0.0 → 1.1.0"

## Implementation Roadmap

**Phase 1 (MVP):** Static JSON packages, declarative validation only
**Phase 2:** Dynamic fields support  
**Phase 3:** Sandboxed custom validators
**Phase 4:** Web UI package uploader
**Phase 5:** ClawHub marketplace

This design gives you:
- ✅ Extensibility without code changes
- ✅ Dynamic fields for complex tools (Notion)
- ✅ Simple validation for most tools
- ✅ Advanced validation when needed
- ✅ Versioning and updates
- ✅ Safe distribution model

Want me to implement Phase 1 (static JSON packages with declarative validation)?