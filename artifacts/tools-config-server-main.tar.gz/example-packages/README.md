# Example Tool Packages

These are example packages showing the Tool Package system.

## Package Structure

Each tool is a folder containing:
- `package.json` — Manifest with schema and validation rules
- `validator.js` (optional) — Custom validation logic
- `README.md` (optional) — Documentation

## Examples Included

### 1. Supabase (Declarative Validation)
Simple database service with HTTP-based validation.
- **Type:** Declarative
- **Fields:** URL, Anon Key, Service Key, Region
- **Validation:** HTTP GET to `/rest/v1/`

### 2. Notion Enhanced (Dynamic Fields)
Notion with unlimited custom database connections.
- **Type:** Dynamic fields
- **Base Fields:** API Token, API Version
- **Dynamic:** Add unlimited database name/ID pairs
- **Use Case:** Your exact scenario — multiple Notion databases

### 3. Stripe (Custom JavaScript)
Payment processor with custom validation logic.
- **Type:** Custom JavaScript validator
- **Fields:** Secret Key, Publishable Key, Webhook Secret, Mode
- **Validation:** JS checks key format + API call

## Installing a Package

### Method 1: Copy to Server
```bash
# On the OpenClaw server
cp -r supabase /home/alex/.openclaw/workspace/tools-server/packages/

# Restart server
cd tools-server
./restart.sh
```

### Method 2: Future UI Upload
1. Zip the package folder
2. Dashboard → "Install Package"
3. Upload zip file
4. Service appears automatically

### Method 3: Future CLI
```bash
claw-tools install ./supabase
# or from URL
claw-tools install https://example.com/supabase-v1.0.0.pkg
```

## Creating Your Own Package

1. Copy `example-packages/template/`
2. Edit `package.json`:
   - Set unique `id`
   - Define your `fields`
   - Add `validation` (declarative or JS)
3. Test locally
4. Share or install

## Field Types Reference

| Type | UI | Validation |
|------|-----|-----------|
| `text` | Text input | Min/max length |
| `password` | Masked input | Pattern matching |
| `url` | URL input | URL format |
| `number` | Number spinner | Min/max value |
| `select` | Dropdown | Must match options |
| `email` | Email input | Email format |

## Validation Types

### Declarative (Simple)
```json
{
  "validation": {
    "type": "http",
    "endpoint": "{{url}}/api/validate",
    "headers": { "Authorization": "Bearer {{apiKey}}" },
    "expectedStatus": 200
  }
}
```

### Custom JavaScript (Advanced)
```json
{
  "validation": {
    "type": "javascript",
    "entry": "validator.js"
  }
}
```

Then create `validator.js`:
```javascript
async function validate(fields) {
  // Custom logic
  return { valid: true, message: "Connected!" };
}
module.exports = { validate };
```

## Dynamic Fields (Notion Use Case)

For tools needing variable number of fields:

```json
{
  "dynamicFields": {
    "enabled": true,
    "label": "Custom Databases",
    "addButtonText": "+ Add Database",
    "maxFields": 20,
    "fieldTemplate": {
      "nameField": {
        "key": "db{{index}}Name",
        "label": "Database {{index}} Name",
        "type": "text"
      },
      "idField": {
        "key": "db{{index}}Id",
        "label": "Database {{index}} ID",
        "type": "text"
      }
    }
  }
}
```

This renders in UI as:
```
[API Token field]
[Version dropdown]

Custom Databases:
┌─ Name: [Home      ] ID: [1c443fe2...] [🗑️]
├─ Name: [Todos     ] ID: [c2cb2ad8...] [🗑️]
├─ Name: [Projects  ] ID: [a1b2c3d4...] [🗑️]
└─ [+ Add Database]
```

## Distribution

### Private (Client Installations)
```bash
tar czf my-tool-v1.0.0.pkg my-tool/
# Send to client, they install via UI
```

### Public (ClawHub - Future)
```bash
claw-tools publish my-tool/
# Available to all OpenClaw users
```

## Security Notes

- Custom validators run in sandboxed VM
- Network requests limited to declared endpoints
- No filesystem access outside package folder
- 10-second timeout enforced
- Memory limits apply

## Questions?

See `../TOOL_PACKAGES.md` for full specification.