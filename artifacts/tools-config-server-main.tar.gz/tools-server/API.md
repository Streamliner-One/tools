# OpenClaw Tools Config Server - API Documentation

## Overview

REST API for managing tool credentials (API keys, tokens, webhooks) with n8n-style multiple instances per connector type.

**Base URL:** `https://your-server:8443`

**Authentication:** Password-protected session cookie

---

## Authentication

### POST /api/login
Login to obtain session cookie.

**Request:**
```json
{
  "password": "your-password"
}
```

**Response:**
```json
{
  "success": true
}
```

Sets `tools_session` cookie for subsequent requests.

---

## Credentials (Main API)

### GET /api/credentials
List all configured credentials.

**Response:**
```json
{
  "credentials": {
    "stripe-123456": {
      "id": "stripe-123456",
      "name": "Stripe - Production",
      "packageId": "stripe",
      "packageName": "Stripe",
      "category": "payment",
      "icon": "💳",
      "fields": {
        "secretKey": { "value": "sk_live_..." },
        "mode": { "value": "live" }
      },
      "usage": {
        "title": "...",
        "curl": "curl ..."
      },
      "createdAt": "2026-03-01T10:00:00Z",
      "updatedAt": "2026-03-01T10:00:00Z"
    }
  }
}
```

### GET /api/credentials/:id
Get specific credential with all field values.

**Response:**
```json
{
  "id": "stripe-123456",
  "name": "Stripe - Production",
  "packageId": "stripe",
  "schema": { /* full package schema */ },
  "fields": {
    "secretKey": { "value": "sk_live_..." },
    "mode": { "value": "live" }
  },
  "usage": {
    "title": "Stripe quick query",
    "summary": "...",
    "curl": "curl ...",
    "expected": "...",
    "commonError": "...",
    "docs": "https://..."
  }
}
```

### GET /api/credentials/:id/usage
Get query example for a credential (resolved with saved field values where available).

### GET /api/credentials/:id/example
Get runnable example definition + parameter schema.

### POST /api/credentials/:id/example/render
Render a copy/paste request + curl with provided params.

**Request:**
```json
{
  "params": {
    "checkInDate": "2026-03-03",
    "checkOutDate": "2026-03-06"
  }
}
```

### POST /api/credentials/:id/example/run
Execute the rendered request server-side (fast mode) and return response.

**Request:**
```json
{
  "params": {
    "q": "waldorf astoria berlin",
    "count": 3
  }
}
```

**Response (example):**
```json
{
  "id": "brave",
  "packageId": "brave",
  "request": {
    "method": "GET",
    "url": "https://api.search.brave.com/res/v1/web/search?q=waldorf+astoria+berlin&count=3",
    "headers": { "X-Subscription-Token": "***redacted***" }
  },
  "response": {
    "status": 200,
    "headers": { "content-type": "application/json" },
    "body": { "web": { "results": [] } }
  }
}
```

### POST /api/credentials
Create new credential instance.

New credentials are automatically pre-populated with service taxonomy metadata (`primaryCategory`, `labels`) from schema, useful for clean installs and agent routing.

**Request:**
```json
{
  "packageId": "stripe",
  "name": "Stripe - Production",
  "fields": {
    "secretKey": { "value": "sk_live_..." },
    "mode": { "value": "live" }
  }
}
```

**Response:**
```json
{
  "success": true,
  "credential": {
    "id": "stripe-1234567890",
    "name": "Stripe - Production",
    "packageId": "stripe"
  }
}
```

### PUT /api/credentials/:id
Update credential (name and/or fields, **merge mode**).

**Request:**
```json
{
  "name": "Stripe - New Name",
  "fields": {
    "secretKey": { "value": "sk_live_new..." }
  }
}
```

### PUT /api/credentials/:id/fields
Replace all credential fields (**full edit mode**).

**Request:**
```json
{
  "fields": {
    "secretKey": { "value": "sk_live_new..." },
    "mode": { "value": "live" }
  }
}
```


### PUT /api/credentials/:id/rename
Rename credential only.

**Request:**
```json
{
  "name": "Stripe - Updated Name"
}
```

### DELETE /api/credentials/:id
Delete credential instance.

**Response:**
```json
{
  "success": true,
  "message": "Credential deleted"
}
```

### POST /api/credentials/:id/validate
Test connection for specific credential.

**Response (success):**
```json
{
  "valid": true,
  "message": "Connected: Account Name (live mode)"
}
```

**Response (failure):**
```json
{
  "valid": false,
  "message": "Invalid API key (401)"
}
```

---

## Health Check

### GET /api/health
System-wide validation of all credentials.

By default this endpoint uses a cached health snapshot (24h TTL) to avoid provider/API overload.
Use `?refresh=true` (or `POST /api/health/refresh`) when a live check is explicitly needed.
TTL override via env: `TOOLS_HEALTH_MAX_AGE_MS`.

### GET /api/health/status
Returns cache metadata only (no live provider calls), including `generatedAt` and summary.

### POST /api/health/refresh
Forces a live health scan and updates cache.

**Response:**
```json
{
  "summary": {
    "total": 26,
    "passed": 23,
    "failed": 0,
    "unknown": 3,
    "allSystemsGo": true,
    "status": "ALL_SYSTEMS_GO"
  },
  "results": [
    {
      "id": "stripe-123456",
      "name": "Stripe - Production",
      "packageId": "stripe",
      "status": "pass",
      "message": "Connected: Streamliner One LLC (live mode)"
    },
    {
      "id": "notion-789",
      "name": "Notion - Work",
      "packageId": "notion",
      "status": "pass",
      "message": "Connected as SuperCEO"
    }
  ]
}
```

**Status values:**
- `pass` - Connection successful
- `fail` - Connection failed (check message)
- `unknown` - No validator configured (normal for OAuth/internal tools)

---

## Package Schemas

### GET /api/services
List all available package types with schemas.

Each service includes:
- `primaryCategory`
- `labels` (multi-label routing/filter tags)

**Response:**
```json
{
  "services": [
    {
      "id": "stripe",
      "name": "Stripe",
      "category": "payment",
      "icon": "💳",
      "description": "Payment processing",
      "fields": [
        {
          "key": "secretKey",
          "label": "Secret Key",
          "type": "password",
          "required": true,
          "sensitive": true,
          "placeholder": "sk_live_..."
        },
        {
          "key": "mode",
          "label": "Mode",
          "type": "select",
          "required": true,
          "options": ["test", "live"],
          "default": "test"
        }
      ]
    }
  ]
}
```

---

## Utility Endpoints

### GET /api/version
Returns current server package version + git SHA/branch, plus last update metadata (`lastSuccessAt`, `lastTargetSha`, etc.).

### GET /api/update/check
Checks remote branch and reports if update is available.

### POST /api/update/run
Starts `update.sh` in background (detached) to update and restart server.

### GET /api/update/status
Returns whether an update process is currently running.

### GET /api/update/log?from=<offset>
Returns incremental update log output for dashboard polling.

### GET /api/toolsmd
Get generated TOOLS.md content.

`TOOLS.md` includes both the schema `category` (primary) and full multi-label taxonomy (`labels`) for each service, so agent-facing docs mirror router metadata.

### POST /api/regenerate
Regenerate TOOLS.md from current credentials.

### GET /api/toolsmd/backups
List available TOOLS.md backups.

### POST /api/toolsmd/restore/:version
Restore from backup (version 1-4).

### GET /api/registry/path
Get registry file path.

### GET /api/router/intents
List supported routing intents.

### GET /api/router?intent=<intent>&includeUnavailable=false&healthyOnly=false
Return ordered candidate packages for an intent, filtered by currently configured credentials.
If `healthyOnly=true`, failed packages from cached health snapshot are deprioritized/filtered without triggering live checks.

### GET /api/oauth/status/:provider?
Return OAuth profile status + TTL and any active dashboard bridge session.
Default provider: `openai-codex`.

### POST /api/oauth/start
Start interactive OAuth bridge session (dashboard-driven) for provider login.
MVP currently supports: `openai-codex`.

Body:
```json
{ "provider": "openai-codex" }
```

### POST /api/oauth/complete
Submit callback URL/code back into the running OAuth CLI session.

Body:
```json
{
  "sessionId": "<uuid>",
  "callbackUrlOrCode": "https://..."
}
```

#### OAuth token persistence runbook (important)
If dashboard re-auth appears successful but expiry later "reverts":

- **Symptom:** modal shows new expiry, card later shows older expiry
- **Root cause:** OpenClaw runtime can keep an older in-memory token and overwrite `auth-profiles.json`
- **Required sync step:**
  - `openclaw models auth paste-token --provider openai-codex --profile-id openai-codex:default --expires-in <N>s`
- **Implementation best practices:**
  1. derive expiry from JWT `exp` (authoritative)
  2. stale-write guard (never overwrite newer token with older)
  3. atomic write (`tmp + rename`)
  4. trigger background health refresh after successful re-auth

**Response:**
```json
{
  "intent": "hotel_search",
  "candidates": [
    { "packageId": "amadeus", "priority": 1, "available": true },
    { "packageId": "duffel", "priority": 2, "available": true }
  ],
  "allCandidates": [
    { "packageId": "amadeus", "priority": 1, "available": true },
    { "packageId": "duffel", "priority": 2, "available": true },
    { "packageId": "goplaces", "priority": 3, "available": false }
  ],
  "failurePolicy": {
    "auth_or_config_error": "fallback_immediately"
  }
}
```

---

## Agent Usage Examples

### Discover Available Tools
```javascript
const tools = await fetch('/api/credentials').then(r => r.json());
// "I see you have Stripe, Notion, OpenAI configured..."
```

### Get API Key When Needed
```javascript
const stripe = await fetch('/api/credentials/stripe-123').then(r => r.json());
const apiKey = stripe.fields.secretKey.value;
// Use with Stripe SDK
```

### Validate Before Using
```javascript
const test = await fetch('/api/credentials/stripe-123/validate', {
  method: 'POST'
}).then(r => r.json());

if (test.valid) {
  // Proceed with API call
} else {
  // Alert user: "Stripe connection failed: Invalid API key"
}
```

### System Health Check
```javascript
const health = await fetch('/api/health').then(r => r.json());

if (health.summary.allSystemsGo) {
  return `✅ All systems go! ${health.summary.passed}/${health.summary.total} integrations passing.`;
} else {
  const failed = health.results.filter(r => r.status === 'fail');
  return `⚠️ Issues detected:\n${failed.map(f => `- ${f.name}: ${f.message}`).join('\n')}`;
}
```

---

## Error Responses

**401 Unauthorized:**
```json
{ "error": "Unauthorized" }
```

**404 Not Found:**
```json
{ "error": "Credential not found" }
```

**400 Bad Request:**
```json
{ "error": "packageId and name required" }
```

**500 Server Error:**
```json
{ "error": "Error message" }
```

---

## Field Types

| Type | UI | Example |
|------|-----|---------|
| `text` | Text input | API URLs, IDs |
| `password` | Masked input | API keys, tokens |
| `url` | URL validation | Webhook endpoints |
| `select` | Dropdown | Mode: test/live |
| `number` | Number input | Port numbers |

---

## Security Notes

- All endpoints require authentication (except `/login`)
- HTTPS only (self-signed cert acceptable)
- Session cookie: `tools_session`
- Password: bcrypt hashed
- Sensitive fields masked in UI
- Keys never logged