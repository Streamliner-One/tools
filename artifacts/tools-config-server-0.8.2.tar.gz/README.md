# tools-config-server — Developer Reference

Internal reference for contributors and maintainers. For product documentation and installation, see the [install repo](https://github.com/Streamliner-One/install).

---

## Quick Start (local dev)

```bash
cd tools-server
npm install

# Development
npm run dev

# Production (Tailscale only)
node server.js --bind 100.x.x.x:8443 --password "your-secure-password"

# Temporary public access (30 min auto-shutdown)
node server.js --temp 30 --bind 0.0.0.0:8443 --https --password "temp-password"
```

## CLI Flags

| Flag | Description | Default |
|------|-------------|---------|
| `--bind HOST:PORT` | Bind address | `127.0.0.1:8080` |
| `--password PASS` | Access password | Auto-generated |
| `--temp MINUTES` | Auto-shutdown after N min | Disabled |
| `--https` | Enable HTTPS (self-signed) | Disabled |
| `--data-dir PATH` | Data directory | `~/.openclaw/workspace` |

## Key Files

| File | Purpose |
|------|---------|
| `schema.js` | Service definitions — fields, validation, labels |
| `server.js` | Express API + health probes |
| `lib/usage.js` | Query examples per service |
| `router.json` | Intent → service routing map |
| `tools-registry.json` | Runtime credential store (never commit) |
| `TOOLS.md` | Auto-generated agent reference (never commit) |
| `CHANGELOG.md` | Version history |
| `RELEASE_CHECKLIST.md` | Step-by-step release process for all 3 repos |

## Architecture

```
┌─────────────┐     ┌──────────────┐     ┌─────────────────┐
│  Web UI     │────▶│  Express API │────▶│  Registry JSON  │
│  (Dark UI)  │     │  (Auth)      │     │  (Local FS)     │
└─────────────┘     └──────────────┘     └─────────────────┘
                             │
                             ▼
                      ┌──────────────┐
                      │  TOOLS.md    │
                      │  Generator   │
                      └──────────────┘
```

## Adding a New Service

1. Add schema to `schema.js`:
```javascript
myService: {
  id: 'myService',
  name: 'My Service',
  category: 'custom',
  icon: '🔧',
  description: 'What it does',
  fields: [
    { key: 'apiKey', label: 'API Key', type: 'password', required: true, sensitive: true }
  ]
}
```

2. Add a health probe to `server.js` under `healthCheckers`

3. Add a usage example to `lib/usage.js` under `getExampleDefinition`

4. Restart server — service appears in the dashboard automatically

## API Endpoints

| Method | Path | Description |
|--------|------|-------------|
| `GET` | `/api/credentials` | All credentials with usage |
| `GET` | `/api/credentials/:id` | Single credential |
| `GET` | `/api/credentials/:id/usage` | Usage example only |
| `POST` | `/api/credentials/:id/example/render` | Rendered curl + request |
| `POST` | `/api/credentials/:id/example/run` | Execute request server-side |
| `PUT` | `/api/credentials/:id` | Merge-update fields |
| `GET` | `/api/health` | Full health snapshot |
| `GET` | `/api/health?refresh=true` | Force fresh health check |
| `GET` | `/api/router?intent=hotel_search` | Intent routing |
| `GET` | `/api/version` | Current version |
| `POST` | `/api/update/run` | Trigger update |

## Releasing

See `RELEASE_CHECKLIST.md` — covers all 3 repos (tools-config-server, install, tools-packages), artifact build, versioning, and GitHub releases.

## License

MIT — Part of OpenClaw ecosystem
