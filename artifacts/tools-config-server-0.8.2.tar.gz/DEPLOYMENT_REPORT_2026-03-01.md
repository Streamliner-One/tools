# Deployment Report — 2026-03-01

## Summary
End-to-end delivery pipeline for Tools Config Server is now operational:

- GitHub org established: `Streamliner-One`
- Repositories initialized and documented
- Installer endpoint live: `https://install.streamliner.one`
- Full VPS installer implemented and validated on fresh Hetzner VM
- Baseline hardening applied (UFW + fail2ban)

## Infrastructure & Repos

### GitHub Organization
- URL: https://github.com/Streamliner-One

### Repositories
- `install` (public)
- `tools-packages` (public)
- `tools-config-server` (private)
- `.github` (org profile/community health)

### Governance
- CODEOWNERS added
- SECURITY policy + issue templates added (org-level)
- Branch protection enabled on public repos
- Release tags created (`v0.1.0`)

## Installer Endpoint

- Domain: `install.streamliner.one`
- Hosting: Netlify (DNS managed by Netlify)
- Root serves installer script directly

Verification:
- `curl -I https://install.streamliner.one` → `200`
- `curl -fsSL https://install.streamliner.one | head` shows bash installer header

## Full Installer Capability

Installer now performs:
1. Dependency install (curl/git/jq/tar)
2. Node.js install/validation (>=18, installs Node 20 when missing)
3. Artifact resolution and download
4. App extraction to `/opt/streamliner/tools-config-server`
5. `npm install --production`
6. Password generation and env file creation (`/etc/default/tools-config-server`)
7. systemd unit creation and start
8. Final output with URL/password/status commands

## Live Test (Hetzner)

Target: `Hetzner test server` (stored in 1Password)

Result:
- Installer completed successfully
- `tools-config-server.service` active/running
- Bound on `0.0.0.0:8443`

## Hardening Applied on Test Server

- UFW enabled
  - default deny incoming
  - allow OpenSSH
  - allow 8443/tcp
- fail2ban installed/enabled
  - sshd jail active
  - `maxretry=5`, `findtime=10m`, `bantime=1h`

## Known Operational Notes

- `tools-config-server` remains private by decision (not open-sourced yet)
- For private repo artifact retrieval, public artifact path strategy is used via `install` repo bundle
- Branch protection may require temporary admin relaxation for solo-owner merge flow; restore immediately after merge

## Next Recommended Steps

1. Add automated build artifact generation for `install/artifacts` (GitHub Action)
2. Add smoke test workflow that validates installer on ephemeral VM/container
3. Add private-to-public release checklist doc for future open-source transition
4. Create production runbook for recurring updates and rollback
