# Model Router + Dashboard OAuth Re-auth Plan

## Goal
Build two high-impact features with minimal complexity:

1. **Model Router v1** — deterministic, budget/intent-aware model selection.
2. **Dashboard OAuth Re-auth** — renew short-lived OAuth credentials without VNC/SSH.

---

## 1) Model Router v1 (Lightweight)

### Design Principles
- Keep it **deterministic** (no hidden heuristics).
- Separate concerns:
  - credentials/auth status
  - model catalog
  - routing policy
- Reuse Tools-server pattern (`router.json` style API).

### Data Files
- `model-router.json`
  - intent -> ordered model aliases/candidates
  - fallback rules
  - optional budget/latency policies
- `model-bindings.json`
  - credential/provider -> allowed model sets (supports OpenRouter-style many models)

### Endpoints (v1)
- `GET /api/models/available`
  - returns currently usable models after intersecting:
    - configured in OpenClaw
    - provider credential available/healthy
    - binding allows model
- `GET /api/model-router?intent=<intent>&budget=<num>&latency=<fast|normal|high-quality>`
  - returns selected model + fallback chain + reason.

### Initial Intent Classes
- `quick_fact`
- `general_chat`
- `deep_reasoning`
- `code_task`
- `creative`
- `cost_sensitive`
- `default`

### Output Shape
```json
{
  "intent": "deep_reasoning",
  "selected": "gpt",
  "fallback": ["sonnet", "opus"],
  "reason": "best quality within budget",
  "candidates": ["gpt", "sonnet", "opus"]
}
```

---

## 2) Dashboard OAuth Re-auth

### Problem
OAuth credentials expire every few days; current flow requires terminal/VNC choreography.

### UX Goal
Dashboard-only flow:
1. Click **Re-auth**
2. Open auth URL
3. Paste callback URL/code
4. Credential renewed

### API Design
- `POST /api/oauth/start`
  - body: `{ provider, credentialId? }`
  - returns: `{ sessionId, authUrl, expiresAt }`
- `GET /api/oauth/status/:sessionId`
  - pending/completed/failed
- `POST /api/oauth/complete`
  - body: `{ sessionId, callbackUrlOrCode }`
  - stores renewed credential/tokens

### Dashboard UI
- OAuth status chip per credential (valid/expiring/expired)
- Re-auth modal:
  - provider info
  - open auth URL button
  - callback paste field
  - submit + result state

### Security
- short-lived oauth sessions
- anti-CSRF state
- callback validation (provider allowlist)
- redact tokens in logs

---

## Suggested Build Order
1. Model router JSON + read-only APIs
2. OAuth start/complete backend skeleton
3. Dashboard OAuth modal
4. Model router selection integration with availability/health

---

## Success Criteria
- Agent can request model route by intent and always get deterministic result.
- User can re-auth OAuth provider from dashboard in under 60 seconds.
- No VNC required for routine token renewals.
